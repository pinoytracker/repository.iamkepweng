# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re, os, urllib, urllib2, sys, inspect, cookielib, requests
#import urlresolver
import resolveurl
#from addon.common.addon import Addon
#from lib import cfscrape
import urlparse
	
cookiejar       = cookielib.CookieJar()
headers         = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36')]
addon_handle    = int(sys.argv[1])
player          = xbmc.Player()
dialog          = xbmcgui.Dialog()
addon2          = xbmcaddon.Addon('plugin.video.PinoyReplay')
addon           = xbmcaddon.Addon()
icon            = addon.getAddonInfo('icon')
addon_name      = addon.getAddonInfo('name')
#ICON            = addon.getAddonInfo('icon2')
Fanart          = addon.getAddonInfo('fanart')
#path            = 'dramacool'
addon_path      = addon.getAddonInfo('path')
Icons2           = addon_path + "/resources/icons/"

#mainurl        = 'https://dramacool9.com/most-popular-drama'#https://www12.dramacool9.io/most-popular-drama
mainurl         = 'https://www1.dramacool.movie/most-popular-drama'
#preurl          = 'https://dramacool9.com/'
preurl          = 'https://www1.dramacool.movie/'

search          = ''

preurl2         = 'https://www1.dramacool.movie/recently-added'
preurl3         = 'https://www1.dramacool.movie'
preurlabs       = ''
preurlresults   = ''
tfcimages       = ''
presearch       = ''
pacitaurl       = ''
kapusourl       = ''
xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

#main_scraper    = 'https://ia600108.us.archive.org/21/items/source_201801/Noypi/listahan_x.txt'

#pinoymovies     = 'https://www.pinoymovieshub.com/'
#
from lib.airtable.airtable import Airtable
		



def add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart='',description=''):
	u = sys.argv[0]+"?mode="+str(mode)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	x=2; num = inspect.getargspec(add_dir); i = len(num[0])
	while i-2 >0:
		u += "&"+num[0][x]+"="+urllib.quote_plus(locals()[num[0][x]])
		x+=1; i-=1
	lis = xbmcgui.ListItem(title,iconImage=iconimage, thumbnailImage=iconimage)
	lis.setInfo( type="Video", infoLabels={"Title": title,"Plot":description})
	#liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	lis.setProperty( "Fanart_Image", fanart)
	if dir_type != '': fo=True
	else: fo=False ; lis.setProperty("IsPlayable","true")
	link = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=lis,isFolder=fo)
	return link



def Get_From_To(text, from_str, to_str, excluding=True):
	if excluding:
		try: r  = re.search("(?i)"+from_str+"([\S\s]+?)"+to_str,text).group(1)
		except: r = ''
	else:
		try: r  = re.search("(?i)("+from_str+"[\S\s]+?"+to_str+")",text).group(1)
		except: r = ''
	return r

def Get_Params():
	args    = sys.argv[2]
	if len(args)<=2: return
	text = re.split('[?]',args,1)
	params1 = {}
	params = urlparse.parse_qs(text[1])
	for i in params:
		x = ''.join(params[i])
		params1.update({i:x})
	return params1

def login():    
	# a = "toomanysecrets"

	# res = raw_input("Please enter your password: ")

	# if res == a:
	#   print "ACCESS GRANTED"
	# else:
	#   print "ACCESS DENIED"
	#Cont = Read_It('http://github.com/pinoytracker/repository.iamkepweng/raw/master/zips/main_x.xml',headers)
	at = Airtable('app4obSw6zHHqkJmS', 'PReplay', api_key='keylWCEKwuRI3rebp')
	match = at.get_all()    
	#xbmc.log('USERNAMESSSSSS##################'+str(match2),2)
	thisRegex = r"'user': u'(.+?)'"
	user = re.compile(thisRegex,re.DOTALL).findall(str(match))[0]
	UserName = addon2.getSetting('Email User')
	
	Password = addon2.getSetting('Password')
	Sagot2 = 'WeareKepweng'

	if UserName == user and Password == Sagot2:
		#dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE')
		Menu()

	else:
		dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE CHANGE THE USERNAME PASSWORD IN THE SETTINGS')
		mode = None
		#exit()
		xbmc.executebuiltin('Dialog.Close(busydialog)')
		xbmc.executebuiltin('Activatewindow(home)')
		addon2.openSettings('plugin.video.PinoyReplay')
	




	# Cont = Read_It(main_scraper,headers)
	# Regex = re.compile('<urlsource11>(.+?)</urlsource>',re.DOTALL).findall(Cont)
	# #xbmc.log('USERNAMESSSSSS##################'+str(Cont),2)
	# for source in Regex:
	#     Sgot = source
	#     UserName = addon2.getSetting('Email User')
	#     Password = addon2.getSetting('Password')
	#     Sagot2 = 'WeareKepweng'
	#     #xbmc.log('USERNAMESSSSSS##################'+str(Sagot2),2)
	#     if UserName == Sgot and Password == Sagot2:
	#         #dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE')
	#         Menu()
	#     else:
	#         dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE CHANGE THE USERNAME PASSWORD IN THE SETTINGS')
	#         mode = None
	#         xbmc.executebuiltin('Activatewindow(home)')
	#         addon2.openSettings('plugin.video.PinoyReplay')



def Menu():
	
	add_dir('f','searchme','','[B][COLOR yellow] SEARCH HERE   ~~~[/COLOR][/B]','',Fanart)
	add_dir('f','displaypage',preurl2,'[B][COLOR yellow] CLICK HERE FOR DRAMACOOL LATEST EPISODE ~~~[/COLOR][/B]','',Fanart)
	add_dir('','','','[B][COLOR yellow]-= POPULAR DRAMAS BELOW =-[/COLOR][/B]','',Fanart)
	
	#LATEST DRAMA BELOW
	#check status code
	readme = requests.get(mainurl,headers)


	cont = Read_It(mainurl,headers)

	main = Get_From_To(cont, "<ul class=\"switch-block list-episode-item\"", "</ul>")
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)href="(.+?)" class="img".+?data-original="(.+?)".+?class="title".+?>(.+?)</h3>',main)
	for url,icon,name in matches:
		holder = preurl+url
		cont2 = Read_It(holder,headers)
		main2 = Get_From_To(cont2, '<div class="details">', '<div class="slider-star">')
		#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
		matches2 = re.findall('(?s)<div class="img">.+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>',main2)
		for title,description,status in matches2:
			description = description
			title = title + ' ([COLOR yellow] STATUS: [/COLOR]' + '[COLOR red]'+status +'[/COLOR])'
		#xbmc.log('URL********################## '+str(url),2)

		#name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
		#if 'http' not in icon:
		#    icon = 'http:' + icon
		#if 'http' not in url:
		#    url = 'http:' + url 
		add_dir('f','displayepisodes',preurl+url,title,icon,icon,description)
	
	#if "<a class='blog-pager-older-link' href=" in cont:
	#np = re.findall('(?s)<span class=\'current\'>.+?href=\'(.+?)\'',cont)
	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',cont)
	
	for url in np:
		url = mainurl + url
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		#url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		#url = ''.join(url)
		add_dir('f','displaypage',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',Icons2 + 'next.png',Fanart)
	xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)

	
	


def Read_It(url,headers=None,post=None,timeout=60,gzip=False):
	opener  = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookiejar),urllib2.HTTPBasicAuthHandler(), urllib2.HTTPSHandler(),urllib2.HTTPHandler())
	req     = urllib2.Request(url)
	if headers:
		for h,hv in headers:
			req.add_header(h,hv)
	scr = opener.open(req,post,timeout=timeout).read()
	if gzip :
		import StringIO, gzip
		cmps = StringIO.StringIO(scr)
		ugzp = gzip.GzipFile(fileobj=cmps)
		scr  = ugzp.read()
	return scr



def Play(url,title,thumb):
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	lis = xbmcgui.ListItem(title,iconImage=thumb,thumbnailImage=thumb)
	lis.setInfo(type='Video', infoLabels ={'Title':title})
	lis.setPath(url)
	player.play(url, lis)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	for i in range(0, 120):
		if player.isPlayingVideo(): break
		xbmc.sleep(1000)
	while player.isPlaying():
		xbmc.sleep(2000)
	xbmc.sleep(4000)

def Searchme():
	keyb = xbmc.Keyboard('', 'Search')
	keyb.doModal()
	if (keyb.isConfirmed()):
		search = keyb.getText().replace(' ','+')
		url = 'https://www1.dramacool.movie/search?type=movies&keyword=' + search
		print 'search me ################# > '+url
	#xbmc.log('################## '+str(url))
	Displaypage(url)


#MainSCRAPER
def Displaypage(url):
	#xbmc.log('##############################################################'+str(url),2)

	cont = Read_It(url,headers)
	main = Get_From_To(cont, '<div class="block tab-container">', '</ul>')
	#main = Get_From_To(cont, '<ul class="switch-block list-episode-item"', '</ul>')
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)href="(.+?)".+?data-original="(.+?)".+?class="title".+?>(.+?)</h3>',main)
	add_dir('f','displaymenu','','[B][COLOR yellow]Home Menu[/COLOR][/B]','','','')
	for url,icon,name in matches: 
		#name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
		#if 'http' not in icon:
		#    icon = 'http:' + icon
		#if 'http' not in url:
		#    url = 'http:' + url 
		add_dir('f','displayepisodes',preurl+url,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,icon,name)
	
	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',cont)
	
	for url in np:
		#xbmc.log('URLCONTENTresolve######################################################################################## '+str(url),2)
		if 'recently-added' in url:

			url = preurl2 + url

		else:    
			url = mainurl + url
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		#url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		#url = ''.join(url)
		add_dir('f','displaypage',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',Icons2 + 'next.png',Fanart)


def Displaycast(url):
	cont = Read_It(url,headers)
	main2 = Get_From_To(cont, 'div class="slider-star">', '<div class="tags">')
	matches2 = re.findall('(?s)<a href="(.+?)".+?<img src="(.+?)".+?">(.+?)</h3>',main2)

	add_dir('f','displaymenu','','[B][COLOR yellow]Home Menu[/COLOR][/B]','','','')
	add_dir('','','','[B][COLOR violet]SELECT FOR THEIR SHOWS[/COLOR][/B]','','','')
	for url,img,artist in matches2:
		url = preurl3 + url
		#xbmc.log('CAST##############################################################'+str(url),2)
		add_dir('f','displaypage',url,'[B][COLOR white]'+artist+'[/COLOR][/B]',img,img,artist)

def Displaycastshows():
	cont = Read_It(url,headers)
	main2 = Get_From_To(cont, '<div class="block-tab">', '<div class="content-right">')
	matches2 = re.findall('(?s)<a href="(.+?)".+?<img src="(.+?)".+?">(.+?)</h3>',main2)
	add_dir('f','displaymenu','','[B][COLOR yellow]Home Menu[/COLOR][/B]','','','')
	add_dir('','','','[B][COLOR yellow]Select Shows Below[/COLOR][/B]','','','')
	for url,img,title in matches2:
		#xbmc.log('IMAGES##############################################################'+str(matches2),2)
		url = preurl3 + url
		add_dir('f','displaypage',url,'[B][COLOR white]'+title+'[/COLOR][/B]',img,img,title)
	#xbmc.log('##############################################################'+str(url),2)

def Displaylinks(url):
	cont = Read_It(url,headers)
	main = Get_From_To(cont, '<div class="anime_muti_link"><ul>', '</ul></div>')
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)<li class=".+?data-video="(.+?)">.+?<span>',main)
	#xbmc.log('##############################################################'+str(matches),2)
	
	for url in matches:

		if 'https:' not in url:
			url = 'https:' + url
		xbmc.log('##############################################################'+str(url),2)
		
		if 'cloud9' in url:
			continue
			# cloud_id = re.compile('https://cloud9.to/embed/([a-zA-Z0-9-]+)',re.DOTALL).findall(url)
			# for cloud_link in cloud_id:
			#     cloud_api = 'https://api.cloud9.to/stream/' + cloud_link
			# xbmc.log('CLOUD ##############################################################'+str(cloud_api),2)
			
			# cheaders = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',
			#             'authority': 'api.cloud9.to',
			#             'origin': 'https://cloud9.to'}

			# read_me = requests.get(cloud_api, headers = cheaders)
			# data = read_me.content
			# xbmc.log('DATA ##############################################################'+str(data),2)
			# thisRegex2 = r'\[\{"file"\:"(.+?)"\}\]'
			# matches2 = re.compile(thisRegex2,re.DOTALL).findall(data)
			# for link in matches2:
			#     link = link.replace('\/','/')
			#     xbmc.log('DATA ##############################################################'+str(link),2)
			#     add_dir('','cloud9resolve',link,'[B][COLOR white]'+link+'[/COLOR][/B]',thumb,'','')



			

	
	#         #http://kshows.to/load.php?id=MTU2ODc0&title=Less+Than+Evil+episode+10&typesub=SUB
		elif 'streaming.php?id' in url:
			#https://embed.dramacool.movie/streaming.php?id=MTkxODQ1&title=Meow%2C+the+Secret+Boy+episode+7&typesub=SUB
			try:
		
				thisRegex = r'https:\/\/embed.dramacool.+?\/streaming.php\?id=(.+?)\&title=(.+?)\&typesub'
				matches = re.compile(thisRegex,re.DOTALL).findall(url)
				for stream_id,title in matches:
					stream_id = stream_id
					title = title

				url = 'https://embed.dramacool.movie/ajax.php'

				kheaders = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',
					'refer': 'https://embed.dramacool.movie/',
					'authority': 'embed.dramacool.movie',
					'x-requested-with': 'XMLHttpRequest'}

				params = {'id': stream_id,
					'title': title,
					'typesub': 'SUB',
					'refer': 'none'}
				
				read_me = requests.get(url, params = params, headers = kheaders)
				data = read_me.content
				
				thisRegex2 = r'\[\{"file"\:"(.+?)","label":"(.+?)"'
				matches2 = re.compile(thisRegex2,re.DOTALL).findall(data)
				for link,name in matches2:
					link = link.replace('\/','/')
					name = name + ' -Server'
					
					#xbmc.log('##############################################################'+str(data),2)
					#xbmc.log('##############################################################'+str('-----'),2)
					#xbmc.log('##############################################################'+str(link),2)
					add_dir('','dramacoolresolve2',link,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,'','')
			except:pass	


			
			

			#holder = Read_It(url,headers)
			#headers2 = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'}
			#read = requests.get(url,headers2)
			#data = read.content
			#xbmc.log('##############################################################'+str(url),2)
	#         #: 'https://hls5x.cdnfile.info/videos/hls/Cc3RoZ8bde-xrbCHUjfB_w/1548785176/156874/b48acf0d1c8d3390bf8065550d01c7fb/ep.10.m3u8',label:
			#url = re.findall('(?s)sources\:\[\{file\: \'(.+?)\',label\:',data)[0]
	#         url = matches
	#         #xbmc.log('embed.dramacool#############################################################'+str(matches),2)
	#     elif 'kshows.to/load.php' in url:
	#         holder = Read_It(url,headers)
	#         #sources:[{file: 'https://hls5x.cdnfile.info/videos/hls/Cc3RoZ8bde-xrbCHUjfB_w/1548785176/156874/b48acf0d1c8d3390bf8065550d01c7fb/ep.10.m3u8',label:
	#        matches = re.findall('(?s)sources\:\[\{file\: \'(.+?)\',label\:',holder)[0]
	#         url = matches

	#     elif 'm3u8' in url:
	#         add_dir('','dramacoolresolve',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,'','')
		else:
			try:
				name = url.split('//')[1].replace('www.','')
				name = name.split('/')[0].split('.')[0].title()
			except:pass           
			host = resolveurl.HostedMediaFile(url)
			ValidUrl = host.valid_url()
			if ValidUrl == True :
				add_dir('','dramacoolresolve',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,'','')
			elif ValidUrl == False:
				#"CANT BE RESOLVED"
				pass
				#"CANT BE RESOLVED"
				



def Displayepisodes(url):
	#xbmc.log('##############################################################'+str(url),2)

	cont = Read_It(url,headers)
	main = Get_From_To(cont, '<div class="details">', '<div class="slider-star">')
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)<div class="img">.+?<img src="(.+?)".+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>',main)
	for icon,title,description,status in matches:
		title = title + ' ([B][COLOR yellow] STATUS: [/COLOR]' + '[COLOR red]'+status +'[/COLOR] )'

   

	#matches2 = re.findall('(?s)[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',matches)
		add_dir('f','displaymenu','','[B][COLOR yellow]Home Menu[/COLOR][/B]','','','')

		add_dir('','','','[B][COLOR white]'+title+'[/COLOR][/B]',icon,icon,description)
		add_dir('f','displaycast',url,'[B][COLOR white]Select Casts for their Shows [/COLOR][/B]',icon,icon,description)

	main2 = Get_From_To(cont, '<div class="block tab-container">', '</ul>')
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches2 = re.findall('(?s)href="(.+?)"(?:.+?)<span class="(?:.+?)">(.+?)</span>(?:.+?)<h3 class="title".+?>(.+?)</h3>',main2)
	
	for url,rs,title in matches2:
		#xbmc.log('URLSSSSSS##################'+str(url),2)
		url = preurl + url
		#xbmc.log('URLSSSSSS##################'+str(url),2)

		show = title.split('   ')[0]
		epi = title.split('Episode')[1]
		rs = (rs + ' ')
		if 'RAW' in rs:
			rs = '[COLOR red]'+rs+'[/COLOR]'
		else:
			rs = '[COLOR yellow]'+rs+'[/COLOR]'
		name = rs + show + ' [COLOR blue](Episode' + epi + ')'
		add_dir('f','displaylinks',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,thumb,desc)

def Dramacoolresolve2(url):
	try:
		#xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',icons + 'icon2.png',10000,False)
		try:
			useragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://embed.dramacool.movie/'
			url = url + useragent 			
			#stream_url = resolveurl.resolve(url)
			lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
			lis.setInfo( type="Video", infoLabels={"Title": title})
			lis.setProperty("IsPlayable","true")
			lis.setPath(url)
			xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
			

		except:
			#url2 = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.m3u8'
			#scrapers = cfscrape.create_scraper()
			#OPEN = scrapers.get(url).content
			#xbmc.log('kvidscraPERURLResolver#################################################################### '+str(url),2)
			
			if 'm3u8' in url:
				newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://k-vid.net/'
				url = url + newuseragent
				xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)
				Play(url,'','')

			if '//k-vid.net' in url:
				#if 'streaming.php' in url
				kvid = 'http:' + url
				#xbmc.log('kvidscraPERURLResolver#################################################################### '+str(kvid),2)
				#url2 = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.m3u8'
				# headers = { 'Accept':'*/*',
				#             'Accept-Enconding':'gzip, deflate, br',
				#             'Accept-Language':'en-US,en;q=0.5',
				#             'Connection':'keep-alive',
				#             'DNT':'1',
				#             'Host':'hls4x.mload.stream',
				#             'Origin':'https://k-vid.net/',
				#             'Referer':'https://k-vid.net/',
				#             'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'}
				
				
				cont = Read_It(kvid,headers)
				
				#xbmc.log('2SCRAPERURLResolver#################################################################### '+str(cont),2)
				try:
					main = Get_From_To(cont, 'countplayer \+\+\;', '\'hls\'')
					matches = re.findall("(?s)sources\:\[\{file\: '(.+?)',label",main)[0]
				
				except:
					main = Get_From_To(cont, 'countplayer \+\+\;', 'auto')
					matches = re.findall("(?s)sources\:\[\{file\: '(.+?)',label",main)[0]
				
				newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://k-vid.net/'
				url = matches + newuseragent
				#xbmc.log('Resolver###################################################'+str(main),2)
				
				#for url in matches:
				#    ref = 'https://www12.dramacool9.io/room-no-9-episode-4.html'
				#url2 = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.720.m3u8'
				#url = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.m3u8' + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://k-vid.net/'
				
				#xbmc.log('Resolver#################################################################### '+str(url),2)
				
				#url = str(url)
				
				#xbmc.log('Resolver#################################################################### '+str(url),2)
				#try:
				#    dialog = xbmcgui.Dialog()
				#    dialog.ok('Network Error', 'Failed to fetch URL', url)
				#except:
				#dialog = xbmcgui.Dialog()
				#dialog.ok('Network Error', 'Failed to fetch URL', url)
				xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)   
				Play(url,'','')

				
	


	except:
		pass
		xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")



def Dramacoolresolve(url):
	try:
		#xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',icons + 'icon2.png',10000,False)
		try:
			xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)
			stream_url = resolveurl.resolve(url)
			lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
			lis.setInfo( type="Video", infoLabels={"Title": title})
			lis.setProperty("IsPlayable","true")
			lis.setPath(stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
			

		except:
			#url2 = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.m3u8'
			#scrapers = cfscrape.create_scraper()
			#OPEN = scrapers.get(url).content
			#xbmc.log('kvidscraPERURLResolver#################################################################### '+str(url),2)
			
			if 'm3u8' in url:
				newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://k-vid.net/'
				url = url + newuseragent
				xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)
				Play(url,'','')

			if '//k-vid.net' in url:
				#if 'streaming.php' in url
				kvid = 'http:' + url
				#xbmc.log('kvidscraPERURLResolver#################################################################### '+str(kvid),2)
				#url2 = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.m3u8'
				# headers = { 'Accept':'*/*',
				#             'Accept-Enconding':'gzip, deflate, br',
				#             'Accept-Language':'en-US,en;q=0.5',
				#             'Connection':'keep-alive',
				#             'DNT':'1',
				#             'Host':'hls4x.mload.stream',
				#             'Origin':'https://k-vid.net/',
				#             'Referer':'https://k-vid.net/',
				#             'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'}
				
				
				cont = Read_It(kvid,headers)
				
				#xbmc.log('2SCRAPERURLResolver#################################################################### '+str(cont),2)
				try:
					main = Get_From_To(cont, 'countplayer \+\+\;', '\'hls\'')
					matches = re.findall("(?s)sources\:\[\{file\: '(.+?)',label",main)[0]
				
				except:
					main = Get_From_To(cont, 'countplayer \+\+\;', 'auto')
					matches = re.findall("(?s)sources\:\[\{file\: '(.+?)',label",main)[0]
				
				newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://k-vid.net/'
				url = matches + newuseragent
				#xbmc.log('Resolver###################################################'+str(main),2)
				
				#for url in matches:
				#    ref = 'https://www12.dramacool9.io/room-no-9-episode-4.html'
				#url2 = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.720.m3u8'
				#url = 'https://hls4x.mload.stream/hls/62587ce65e265901ca2e73fab150154c/ep.4.m3u8' + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://k-vid.net/'
				
				#xbmc.log('Resolver#################################################################### '+str(url),2)
				
				#url = str(url)
				
				#xbmc.log('Resolver#################################################################### '+str(url),2)
				#try:
				#    dialog = xbmcgui.Dialog()
				#    dialog.ok('Network Error', 'Failed to fetch URL', url)
				#except:
				#dialog = xbmcgui.Dialog()
				#dialog.ok('Network Error', 'Failed to fetch URL', url)
				xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)   
				Play(url,'','')

				
	


	except:
		pass
		xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")




	




params = Get_Params()
mode = None

try: mode = params['mode']
except: pass
try: url = params['url']
except: pass
try: title = params['title']
except: pass
try: thumb = params['iconimage']
except: pass
try: bg = params['fanart']
except: pass
try: desc = params['description']
except: pass

if mode == None or len(sys.argv[2])<2: login()


if mode == 'searchme':
	Searchme()

if mode == 'displaymenu':
	Menu()  
	
if mode == 'displaycast':
	Displaycast(url)

if mode == 'displaycastshows':
	Displaycastshows()  


if mode == 'displayepisodes':
	Displayepisodes(url)

	

if mode == 'displaylinks':
	Displaylinks(url)

if mode == 'dramacoolresolve':
	Dramacoolresolve(url)

if mode == 'dramacoolresolve2':
	Dramacoolresolve2(url)


if mode == 'displaypage':
	Displaypage(url)
	
	


if mode == 'kapusoresolve':
	
	
	
	#if '.mp4' in url:
	#   Play(url,'','')
		
	if 'vidoza' in url:
		#xbmc.log('VIDOZA###################################################################### '+str(url),2)

		stream_url = urlresolver.resolve(url)
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
			
	elif 'relaxpinas' in url:
		#xbmc.log('RELAXPINAS###################################################################### '+str(url),2)
		Holder = Read_It(url,headers)
		#xbmc.log('Holder###################################################################### '+str(Holder),2)
		
		Relaxmain = Get_From_To(Holder,"var playlist = [\[]","[\]];")
		
		
		Relaxsources = re.findall('(?s)\'(.+?)\'',Relaxmain)
		#xbmc.log('Relaxsources###################################################################### '+str(Relaxmain),2)
		for url in Relaxsources:
			

			url = str(url)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'
		Play(url,'','')

	elif 'openload' in url:
		stream_url = urlresolver.resolve(url)
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)

	elif 'dailymotion' in url:
		#xbmc.log('Dailymotion###################################################################### '+str(url),2)
		stream_url = urlresolver.resolve(url)
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)

	elif 'ok.ru' in url:
		#url = 'https:' + url
		#url = str(url)
		stream_url = urlresolver.resolve(url)
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)



	elif 'libangan' or 'lambingan' in url:
		Holder = Read_It(url,headers)
		Holder2 = Get_From_To(Holder,"<head>","</body>")
		#xbmc.log('HOLDER######################################################### '+str(Holder),2)

		if 'openload.co' in Holder:
			#openload = Get_From_To(Holder,"<body id=\"top\">","</body></html>")
			openloadurl = re.findall('(?s)<a href="(.+?)"',Holder2)
			
			for url in openloadurl:
				url = url
			stream_url = urlresolver.resolve(url)

		if 'ok.ru' in Holder:
			#ok = Get_From_To(Holder,"<body id=\"top\">","</body></html>")
			okurl = re.findall('(?s)<iframe.+?src="(.+?)"',Holder2)
			for url in okurl:
				url = 'https:' + url
			stream_url = urlresolver.resolve(url)

		if 'vidoza' in Holder:
			vidozaurl = re.findall('(?s)<a href="(.+?)"',Holder2)
			for url in vidozaurl:
				url = url
			stream_url = urlresolver.resolve(url)

		if 'estream' in Holder:
			estreamurl = re.findall('(?s)<a href="(.+?)"',Holder2)
			for url in estreamurl:
				url = url
			stream_url = urlresolver.resolve(url)

		if 'streamango' in Holder:
			streamangourl = re.findall('(?s)<a href="(.+?)"',Holder2)
			for url in streamangourl:
				#xbmc.log('######################################################### '+str(url),2)

				url = url
			stream_url = urlresolver.resolve(url)

		if 'dailymotion' in Holder:
			dailymotionurl = re.findall('(?s)<iframe.+?src="(.+?)"',Holder2)
			for url in dailymotionurl:
				url = url
			stream_url = urlresolver.resolve(url)

		
		else:
			stream_url = urlresolver.resolve(url)
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)  
			
			
			

		

	elif 'vidoza' or 'openload' not in url:
		try:
			Play(url,'','')
		
		except:

			stream_url = urlresolver.resolve(url)
			lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
			lis.setInfo( type="Video", infoLabels={"Title": title})
			lis.setProperty("IsPlayable","true")
			lis.setPath(stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	
	else:
		
		xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")


	







xbmcplugin.endOfDirectory(addon_handle)