'''
    Stadium Live Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,re,os,urllib,urllib2,json,base64
from urllib2 import urlopen
import xbmc,xbmcgui,xbmcplugin,xbmcaddon

headers  = '|User-Agent=Mozilla/5.0 (Linux; U; Android 4.4.2; SM-G900F Build/KOT49H)Gecko/20100101 Firefox/42.0 Iceweasel/42.0'
dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
addon_logo = xbmc.translatePath(os.path.join(plugin_path,'tvaddons_logo.png'))

player 		= xbmc.Player()
dialog      = xbmcgui.Dialog()

def find_single_match(text,pattern):
    result = ""
    try:    
        matches = re.findall(pattern,text,flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""
    return result

def cleanHex(text):
    def fixup(m):
	text = m.group(0)
	if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
	else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))

def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    link = cleanHex(link)
    response.close()
    return link

def Play(url,title,thumb):
	if not 'rtmp' in url:
		url = url+headers
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	lis	= xbmcgui.ListItem(title,iconImage=thumb,thumbnailImage=thumb)
	lis.setInfo(type='Video', infoLabels ={'Title':title})
	lis.setPath(url)
	player.play(url, lis)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	for i in range(0, 120):
		if player.isPlayingVideo(): break
		xbmc.sleep(1000)
	while player.isPlaying():
		xbmc.sleep(2000)
	xbmc.sleep(4000)

if __name__ == '__main__':
    xbmcgui.Dialog().notification(addon_name + ' is provided by:','www.tvaddons.co',addon_logo,10000,False)

    #Get stream
    link = open_url(base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvbGl2ZXR2X2RpcmVjdC92MS9nZXRfc3RyZWFtLnBocD9pZD1zdGFkaXVt'))
    json = json.loads(link)
    xbmc.log('USERNAMESSSSSS##################'+str(json),2)
    #stream = json["results"][0]["stream"]
    #stream = 'http://stream3.news5.ph:1935/n5e/tv5/chunklist_w718385065.m3u8'
    #stream = 'http://stream3.news5.ph:1935/n5e/tv5/media_w1698063979_9800.ts'
    #http://stream3.news5.ph:1935/n5e/tv5/media_w1630890826_26405.ts
    stream = 'http://stream3.news5.ph:1935/n5e/tv5/playlist.m3u8'
    #stream = 'https://mlblive-akc.mlb.com/ls01/mlbam/mlb_network/NETWORK_LINEAR_1/master_wired.m3u8'

    if "m3u8" in stream and stream != "null":
    #if "asx" in stream and stream != "null":
        xbmc.executebuiltin('Activatewindow(home)')
        #li = xbmcgui.ListItem(addon_name)
        #xbmc.Player().play(stream,li,False)
        Play(stream,'','')
    else:
        dlg.ok(addon_name, "Unable to get stream. Please try again later.")
        xbmc.executebuiltin('Activatewindow(home)')
