# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re, os, urllib, urllib2, sys, inspect, cookielib
#import urlresolver
import resolveurl as urlresolver
#from addon.common.addon import Addon
import urlparse

cookiejar 		= cookielib.CookieJar()
headers 		= [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36')]
addon_handle 	= int(sys.argv[1])
player 			= xbmc.Player()
dialog 			= xbmcgui.Dialog()
addon 			= xbmcaddon.Addon()
icon 			= addon.getAddonInfo('icon')
Fanart 			= addon.getAddonInfo('fanart')
path 			= 'PinoyReplay'
addon_path 		= addon.getAddonInfo('path')
icons 			= addon_path + "/resources/icons/"

url 			= 'http://www.pinoyrewind.info/search/label/HOME?&max-results=48'
preurl 			= 'http://www.pinoyrewind.info'
search 			= 'http://www.pinoyrewind.info/search?q='
preurl2			= 'http://www.pinoyrewind.info/search/label/'
preurl3			= '?max-results=50'
tfcimages		= 'https://img.tfc.tv/xcms/'

pinoymovies 	= 'https://www.pinoymovieshub.com/'






	


def add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
	u = sys.argv[0]+"?mode="+str(mode)+"&iconimage="+urllib.quote_plus(iconimage)
	x=2; num = inspect.getargspec(add_dir); i = len(num[0])
	while i-2 >0:
		u += "&"+num[0][x]+"="+urllib.quote_plus(locals()[num[0][x]])
		x+=1; i-=1
	lis = xbmcgui.ListItem(title,iconImage=iconimage, thumbnailImage=iconimage)
	lis.setInfo( type="Video", infoLabels={"Title": title})
	lis.setProperty( "Fanart_Image", fanart)
	if dir_type != '': fo=True
	else: fo=False ; lis.setProperty("IsPlayable","true")
	link = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=lis,isFolder=fo)
	return link



def Get_From_To(text, from_str, to_str, excluding=True):
	if excluding:
		try: r 	= re.search("(?i)"+from_str+"([\S\s]+?)"+to_str,text).group(1)
		except: r = ''
	else:
		try: r 	= re.search("(?i)("+from_str+"[\S\s]+?"+to_str+")",text).group(1)
		except: r = ''
	return r

def Get_Params():
	args	= sys.argv[2]
	if len(args)<=2: return
	text = re.split('[?]',args,1)
	params1	= {}
	params = urlparse.parse_qs(text[1])
	for i in params:
		x = ''.join(params[i])
		params1.update({i:x})
	return params1

def login():
    
    # a = "toomanysecrets"

    # res = raw_input("Please enter your password: ")

    # if res == a:
    #   print "ACCESS GRANTED"
    # else:
    #   print "ACCESS DENIED"
    Cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
    Regex = re.compile('<urlsource7>(.+?)</urlsource>',re.DOTALL).findall(Cont)
    #xbmc.log('USERNAMESSSSSS##################'+str(UserName),2)
    for source in Regex:
        Sgot = source
        UserName = addon.getSetting('Email User')
        Password = addon.getSetting('Password')
        Sagot2 = 'WeareKepweng'
        #xbmc.log('USERNAMESSSSSS##################'+str(Sagot2),2)
        if UserName == Sgot and Password == Sagot2:
            #dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE')
            Menu()
        else:
            dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE CHANGE THE USERNAME PASSWORD IN THE SETTINGS')
            mode = None
            exit()


def Menu():
	add_dir('f','latest','','[B][COLOR yellow]LATEST EPISODES[/COLOR][/B]','',Fanart)
	add_dir('f','latest2','','[B][COLOR yellow]LATEST EPISODES2[/COLOR][/B]','',Fanart)
	#add_dir('f','pmovies','','[B][COLOR yellow]PINOY MOVIES[/COLOR][/B]','',Fanart)
	add_dir('f','drama2','','[B][COLOR yellow]DRAMA 2[/COLOR][/B]','',Fanart)
	add_dir('f','drama7','','[B][COLOR yellow]DRAMA 7[/COLOR][/B]','',Fanart)
	add_dir('f','news','','[B][COLOR yellow]NEWS[/COLOR][/B]','',Fanart)
	add_dir('f','variety','','[B][COLOR yellow]VARIETY SHOWS[/COLOR][/B]','',Fanart)
	add_dir('f','comedy','','[B][COLOR yellow]COMEDY[/COLOR][/B]','',Fanart)
	add_dir('f','weekend','','[B][COLOR yellow]WEEKEND SHOWS[/COLOR][/B]','',Fanart)
	add_dir('f','old','','[B][COLOR yellow]OLD DRAMA[/COLOR][/B]','',Fanart)
	


def Read_It(url,headers=None,post=None,timeout=20,gzip=False):
	opener 	= urllib2.build_opener(urllib2.HTTPCookieProcessor(cookiejar),urllib2.HTTPBasicAuthHandler(), urllib2.HTTPSHandler(),urllib2.HTTPHandler())
	req     = urllib2.Request(url)
	if headers:
		for h,hv in headers:
			req.add_header(h,hv)
	scr = opener.open(req,post,timeout=timeout).read()
	if gzip :
		import StringIO, gzip
		cmps = StringIO.StringIO(scr)
		ugzp = gzip.GzipFile(fileobj=cmps)
		scr  = ugzp.read()
	return scr



def Play(url,title,thumb):
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	lis	= xbmcgui.ListItem(title,iconImage=thumb,thumbnailImage=thumb)
	lis.setInfo(type='Video', infoLabels ={'Title':title})
	lis.setPath(url)
	player.play(url, lis)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	for i in range(0, 120):
		if player.isPlayingVideo(): break
		xbmc.sleep(1000)
	while player.isPlaying():
		xbmc.sleep(2000)
	xbmc.sleep(4000)


def  Results(content):
	main = Get_From_To(content,"<div class='blog-posts hfeed'>","<div class='blog-feeds'>")
	#Regex = re.findall('(?s)href=["](.+?)["]>(.+?)<' ,OPEN)
	#matches = re.compile('(?s)(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)&(?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)&(?:.+?);(.+?)"[)][)];',main)
	
	for i in matches:
		#xbmc.log('********################## '+str(i[0]),2)
		#add_dir('f','csear',i[0],'[COLOR cyan]'+i[2]+'[/COLOR][COLOR white] '+i[3]+' [/COLOR]',i[1],fanart)
		add_dir('f','page',i[0],'[B][COLOR yellow]'+i[2]+'[/COLOR][COLOR white]'+i[3]+' [/COLOR][/B]',i[1],fanart)
		xbmc.executebuiltin('Container.SetViewMode(55)') 
		
	if 'Next Post' in main:
		link = Get_From_To(main,"blog-pager-older-link' href='","'")
		add_dir('f','csear',link,'[B][COLOR red]Next Page or previous page if no more pages [/COLOR][/B]',icon,fanart)






params = Get_Params()
mode = None

try: mode = params['mode']
except: pass
try: url = params['url']
except: pass
try: title = params['title']
except: pass
try: thumb = params['iconimage']
except: pass
try: fanart = params['fanart']
except: pass

if mode == None or len(sys.argv[2])<2: login()



if mode == 'csear':
	content = Read_It(url,headers)
	#xbmc.log('MAIN2######################################################### '+str(content),2)
	Results(content)


if mode == 'page':

	content = Read_It(url,headers)
	main = Get_From_To(content,"<div class=\"tabber\">","<div id='fb-root'></div>")
	matches = Get_From_To(main,"<div class=\"tabbertab\" title=\"Server 1\">","<div style='clear: both;'></div>")
	matches2 = re.findall('(?s)[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',matches)

	matches3 = Get_From_To(main,"<div class=\"tabbertab\"","</IFRAME>")
	matches4 = re.findall('(?s)[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',matches3)
	

	add_dir('','','','[B][COLOR white]~~~ CHOOSE MAIN LINK BELOW[/COLOR][/B]',thumb,thumb)

	if not matches2:
			add_dir('','','','[B][COLOR red]** NOT YET AVAILABLE CHECK BACK LATER **[/COLOR][/B]',thumb,thumb)
	

	for url in matches2:
		
		try:
			name2 = url.split('//')[1].replace('www.','')
			name2 = name2.split('/')[0].split('.')[0].title()
		except:pass
		
		add_dir('','resolve2',url,'[B][COLOR yellow]'+name2+'[/COLOR][/B]',thumb,thumb)
	
	

    # IS IT POSSIBLE TO MAKE THIS PART A PLAYLIST / BUT SOMETIMES IT  IS A SINGLE LINK
	add_dir('','','','[B][COLOR white]~~~ CHOOSE ALTERNATE LINK BELOW[/COLOR][/B]',thumb,thumb)

	
	for url2 in matches4:
		
		content2 = Read_It(url2,headers)
		main2 = Get_From_To(content2,"var playlist = [\[]","[\]];")
		matches5 = re.findall('(?s)\'(.+?)\'\,',main2)
		counter = 0
		bilang = 0

		for counters in matches5:			

			bilang = bilang + 1
			
		if bilang > 1:


			for url3 in matches5:
				counter = counter + 1
				name2 = 'Part' + str(counter)
				add_dir('','resolve2',url3,'[B][COLOR yellow]'+name2+'[/COLOR][/B]',thumb,thumb)


		else:

			for url3 in matches5:			

				#counter = counter + 1
				#name2 = 'Part ' + str(counter)

				add_dir('','resolve2',url3,'[B][COLOR yellow]RelaxPinas[/COLOR][/B]',thumb,thumb)



				#xbmc.log('MAIN2######################################################### '+str(url3),2)
	



if mode == 'resolve2':
    #xbmc.log('URLCONTENTresolve######################################################################################## '+str(url),2)
    if 'vidoza' in url:

       	stream_url = urlresolver.resolve(url)
       	lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
    	lis.setInfo( type="Video", infoLabels={"Title": title})
    	lis.setProperty("IsPlayable","true")
    	lis.setPath(stream_url)
    	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
        	
    elif 'openload' in url:
    	stream_url = urlresolver.resolve(url)
    	lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
    	lis.setInfo( type="Video", infoLabels={"Title": title})
    	lis.setProperty("IsPlayable","true")
    	lis.setPath(stream_url)
    	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)

    elif 'vidoza' or 'openload' not in url:
    	try:
    		Play(url,'','')
    	
    	except:

    		stream_url = urlresolver.resolve(url)
    		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
    		lis.setInfo( type="Video", infoLabels={"Title": title})
    		lis.setProperty("IsPlayable","true")
    		lis.setPath(stream_url)
    		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
    
    else:
    	
    	xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")




if mode == 'old':

	add_dir('f','absdrama','','[B][COLOR yellow]ABS DRAMA[/COLOR][/B]','',Fanart)
	add_dir('f','gmadrama','','[B][COLOR yellow]GMA DRAMA[/COLOR][/B]','',Fanart)


if mode == 'gmadrama':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<olddrama>", "</olddrama>")
	drama = Get_From_To(main, "<drama2>", "</drama2>")
	weekend = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", drama)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	#xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon in weekend:
		if 'http' not in icon:
			icon = tfcimages + icon
		if 'http' not in fanart:
			fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)



if mode == 'absdrama':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<olddrama>", "</olddrama>")
	drama = Get_From_To(main, "<drama1>", "</drama1>")
	weekend = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", drama)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	#xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon in weekend:
		if 'http' not in icon:
			icon = tfcimages + icon
		if 'http' not in fanart:
			fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)


if mode == 'weekend':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<weekendshows>", "</weekendshows>")
	#drama = Get_From_To(main, "<drama1>", "</drama1>")
	weekend = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", main)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	#xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon in weekend:
		if 'http' not in icon:
			icon = tfcimages + icon
		if 'http' not in fanart:
			fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)



if mode == 'comedy':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<comedy>", "</comedy>")
	#drama = Get_From_To(main, "<drama1>", "</drama1>")
	comedy = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", main)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	#xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon in comedy:
		if 'http' not in icon:
			icon = tfcimages + icon
		if 'http' not in fanart:
			fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)



if mode == 'news':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<news>", "</news>")
	#drama = Get_From_To(main, "<drama1>", "</drama1>")
	news = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", main)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	#xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon in news:
		if 'http' not in icon:
			icon = tfcimages + icon
		if 'http' not in fanart:
			fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)



if mode == 'variety':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<varietyshows>", "</varietyshows>")
	#drama = Get_From_To(main, "<drama1>", "</drama1>")
	variety = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", main)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	#xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon in variety:
		if 'http' not in icon:
			icon = tfcimages + icon
		if 'http' not in fanart:
			fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)

if mode == 'drama2':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<newdrama>", "</newdrama>")
	drama = Get_From_To(main, "<drama1>", "</drama1>")
	drama1 = re.findall("(?s)'(.+?)','(.+?)','(.+?)','(.+?)'", drama)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	#xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon,fanart in drama1:
		if 'http' not in icon:
			icon = tfcimages + icon
		if 'http' not in fanart:
			fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,fanart)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)


if mode == 'drama7':
	####
	#content = Read_It(url,headers)
	#main = Get_From_To(content,"<MAINNETWORKDOS>","</MAINNETWORKDOS>")
	#matches = Get_From_To(main,"<TITLEWEEKENDSHOWS>","</TITLEWEEKENDSHOWS>")
	#matches2 = re.findall("(?s)'(.+?)','(.+?)','(.+?)'", matches)
	#xbmc.log('######################################################### '+str(main),2)

	####
	cont = Read_It('https://ia600108.us.archive.org/21/items/source_201801/Noypi/main_x.xml',headers)
	main = Get_From_To(cont, "<newdrama>", "</newdrama>")
	drama = Get_From_To(main, "<drama2>", "</drama2>")
	drama1 = re.findall("(?s)'(.+?)','(.+?)','(.+?)','(.+?)'", drama)
	#matches = re.compile('(?s)<drama1>(.+?)</drama1>',re.DOTALL).findall(main)
	#matches = Get_From_To(main,"<drama1>","</drama1>")
	#drama1 = re.compile("(?s)('(.+?)','(.+?)','(.+?)','(.+?)')",re.DOTALL).findall(str(matches)
	
	xbmc.log('URLCONTENTresolve######################################################################################## '+str(drama1),2)
	

	for name,url,icon,fanart in drama1:
		#if 'http' not in icon:
		#	icon = tfcimages + icon
		#if 'http' not in fanart:
		#	fanart = tfcimages + fanart
		if 'http' not in url:
			url = preurl2 + url + preurl3
		add_dir('f','csear',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,fanart)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)


if mode == 'latest2':

	cont = Read_It('http://www.lambingan.su/',headers)
	main = Get_From_To(cont, "<div id=\"nav\">", "<div class='wp-pagenavi cat-navi'><span class=\"pages\">")
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)class="post-thumbnail".+?img src="(.+?)".+?href="(.+?)" title="(.+?)"',main)
	for icon,url,name in matches: 
		name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
		if 'http' not in icon:
			icon = 'http:' + icon
		add_dir('f','page',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)
	
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)




if mode == 'latest':

	cont = Read_It('http://www.pinoyrewind.info/search/label/HOME?&max-results=20',headers)
	main = Get_From_To(cont, "<div class='blog-posts hfeed'>", "<span id='blog-pager-older-link'>")
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];',main)
	for i in matches: 
		t = ''.join(i[2])
		if len(t) > 25 : 
			t = t[:35]
		zx = ''.join(i[3])
		if 'div class=' in zx : zx = ''
		add_dir('f','page',i[0],'[B][COLOR yellow]'+t+'[/COLOR][COLOR white] '+zx+' [/COLOR][/B]',i[1],i[1])
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icon,fanart)



xbmcplugin.endOfDirectory(addon_handle)