# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re, os, urllib, urllib2, sys, inspect, cookielib
import urlresolver
#from addon.common.addon import Addon
import urlparse

cookiejar 		= cookielib.CookieJar()
headers 		= [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36')]
addon_handle 	= int(sys.argv[1])
player 			= xbmc.Player()
dialog 			= xbmcgui.Dialog()
addon 			= xbmcaddon.Addon()
icon 			= addon.getAddonInfo('icon')
fanart 			= addon.getAddonInfo('fanart')
path 			= 'PinoyReplay'
addon_path 		= addon.getAddonInfo('path')
icons 			= addon_path + "/resources/icons/"
url 			= 'http://www.pinoyrewind.info/search/label/ABS-CBN?&max-results=24'
preurl 			= 'http://www.pinoyrewind.info'
search 			= 'http://www.pinoyrewind.info/search?q='
#xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')+
#xbmcplugin.setContent(int(sys.argv[1]), 'movies')


def add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
	u = sys.argv[0]; u += "?mode="+str(mode)
	x=2; num = inspect.getargspec(add_dir); i = len(num[0])
	while i-2 >0:
		u += "&"+num[0][x]+"="+urllib.quote_plus(locals()[num[0][x]])
		x+=1; i-=1
	lis = xbmcgui.ListItem(title,iconImage=iconimage, thumbnailImage=iconimage)
	lis.setInfo( type="Video", infoLabels={"Title": title})
	lis.setProperty( "Fanart_Image", fanart)
	if dir_type != '': fo=True
	else: fo=False ; lis.setProperty("IsPlayable","true")
	link = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=lis,isFolder=fo)
	return link



def Get_From_To(text, from_str, to_str, excluding=True):
	if excluding:
		try: r 	= re.search("(?i)"+from_str+"([\S\s]+?)"+to_str,text).group(1)
		except: r = ''
	else:
		try: r 	= re.search("(?i)("+from_str+"[\S\s]+?"+to_str+")",text).group(1)
		except: r = ''
	return r

def Get_Params():
	args	= sys.argv[2]
	if len(args)<=2: return
	text = re.split('[?]',args,1)
	params1	= {}
	params = urlparse.parse_qs(text[1])
	for i in params:
		x = ''.join(params[i])
		params1.update({i:x})
	return params1

def Menu2(url):
	# a = "toomanysecrets"

	# res = raw_input("Please enter your password: ")

	# if res == a:
	# 	print "ACCESS GRANTED"
	# else:
	# 	print "ACCESS DENIED"

	kb = xbmc.Keyboard(None, 'Enter Search Terms')
	kb.doModal()
	if (kb.isConfirmed()):
		st = kb.getText()
		if st == 'password': 
			#dialog.ok('yes')
			Menu(url)
		else:
			dialog.ok('SORRY WRONG PASSWORD','PLEASE TRY AGAIN','CONTACT THE ADMIN','Click ok to continue')
			mode = None
			Menu2(url)
	else:
		exit()

def Menu(url):
	add_dir('f','searc','','[COLOR limegreen]Search for your Favorite shows here [/COLOR][COLOR white] TV Series Search [/COLOR]',icon,fanart)
	#add_dir('','','','',icon,fanart)
	#add_dir('f','movie','','[COLOR orange] Click here to get your Movie listings[/COLOR]',icon,fanart)
	#add_dir('','','','',icon,fanart)
	add_dir('f','ABS','','[COLOR yellow]ABS CBN DRAMA SHOWS[/COLOR]',icons +'kapamilya_drama.jpg',fanart)
	add_dir('f','VS','','[COLOR yellow]ABS CBN VARIETY/REALITY SHOWS[/COLOR]',icons +'kapamilya_variety.jpg',fanart)
	add_dir('f','CMY','','[COLOR yellow]ABS CBN COMEDY[/COLOR]',icons +'kapamilya_comedy.jpg',fanart)
	add_dir('f','WS','','[COLOR yellow]ABS CBN WEEKEND SHOWS[/COLOR]',icons +'kapamilya_drama.jpg',fanart)
	add_dir('f','NCP','','[COLOR yellow]ABS CBN NEWS/CURRENT AFFAIRS[/COLOR]',icons +'kapamilya_weekendshows.jpg',fanart)
	add_dir('f','latest','','[COLOR yellow]LATEST EPISODES[/COLOR]',icon,fanart)
	 
	



def Read_It(url,headers=None,post=None,timeout=20,gzip=False):
	opener 	= urllib2.build_opener(urllib2.HTTPCookieProcessor(cookiejar),urllib2.HTTPBasicAuthHandler(), urllib2.HTTPSHandler(),urllib2.HTTPHandler())
	req     = urllib2.Request(url)
	if headers:
		for h,hv in headers:
			req.add_header(h,hv)
	scr = opener.open(req,post,timeout=timeout).read()
	if gzip :
		import StringIO, gzip
		cmps = StringIO.StringIO(scr)
		ugzp = gzip.GzipFile(fileobj=cmps)
		scr  = ugzp.read()
	return scr

def Search():
	kb = xbmc.Keyboard(None, 'Enter Search Terms')
	kb.doModal()
	if (kb.isConfirmed()):
		st = kb.getText()
		if (st is None or st == ''): 
			Menu(url)
		try:
			st = st.replace(' ','%20')
			content = Read_It(search+st,headers)
			return content
		except:
			Menu(url)

def Results(content):
	main = Get_From_To(content,"<div class='blog-posts hfeed'>","<div class='blog-feeds'>")
	#Regex = re.findall('(?s)href=["](.+?)["]>(.+?)<' ,OPEN)
	#matches = re.compile('(?s)(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)&(?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)&(?:.+?);(.+?)"[)][)];',main)
	
	for i in matches:
		#xbmc.log('********################## '+str(i[0]),2)
		#add_dir('f','csear',i[0],'[COLOR cyan]'+i[2]+'[/COLOR][COLOR white] '+i[3]+' [/COLOR]',i[1],fanart)
		add_dir('','page',i[0],'[COLOR cyan]'+i[2]+'[/COLOR][COLOR white] '+i[3]+' [/COLOR]',i[1],fanart)
		xbmc.executebuiltin('Container.SetViewMode(55)') 
		
	if 'Next Post' in main:
		link = Get_From_To(main,"blog-pager-older-link' href='","'")
		add_dir('f','csear',link,'[COLOR red]Next Page or previous page if no more pages [/COLOR]',icon,fanart)



def Check(url,headers):
	content = Read_It(url,headers)
	cont = Get_From_To(content,'<div class="tabber">', "<div id='fb-root'></div>")
	#matches = re.compile('(?s)(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)&(?:.+?);(.+?)"[)][)];').findall(cont)
	try:
		if 'cloudupload' in cont:
			file = 'cloud'
			return cont, file
		elif 'Speedvid' in cont:
			file = 'speed'
			return cont, file
		elif 'vidoza' in cont:
			file = 'vid'
			return cont, file  
		elif 'estream' in cont:
			file = 'es'
			return cont, file
		elif 'kingvid' in cont:
			file = 'king'
			return cont, file
		

		# elif 'vidoza' in cont:
			 
		# 	stream_url = urlresolver.resolve(url)
		# 	liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
		# 	liz.setInfo(type="Video", infoLabels={"Title": description})
		# 	liz.setProperty("IsPlayable","true")
		# 	liz.setPath(stream_url)
		# 	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

		# else: 
		# 	stream_url = urlresolver.resolve(url)
		# 	liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
		# 	liz.setInfo(type="Video", infoLabels={"Title": description})
		# 	liz.setProperty("IsPlayable","true")
		# 	liz.setPath(stream_url)
		# 	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)	

	except:pass

	
	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	dialog.ok('NO Links Found','No Playable Links were found for this stream service','Try another stream','Click ok to continue')
	
	file = 'shagged'
	return cont, file
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	



# def Speedvid(content,url,title,thumb):
# 	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
# 	link 	= re.compile('http:[/][/]www.speedvid(.+?)"').findall(content)
# 	link 	= 'http://www.speedvid'+''.join(link)
# 	headers = [('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'), ('referer', url)]
# 	content = Read_It(link,headers)
# 	url 	= re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|').findall(content)
# 	for port,server,hash in link:
# 		url = 'http://'+server+'.speedvid.net:'+port+'/'+hash+'/v.mp4'
# 	url 	= ''.join(url)
# 	url 	= str(url)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'
# 	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
# 	xbmc.log('###############'+str(url))
# 	Player(url,title,thumb)


def Play_vid(content,url,title,thumb):

	#xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	#Regex = re.findall('(?s)href=["](.+?)["]>(.+?)<' ,OPEN)
	#link 	= re.compile('https:[/][/]vidoza(.+?)"').findall(content)
	link 	= re.findall('https:[/][/]vidoza(.+?)"',content)
	link 	= 'https://vidoza'+''.join(link)
	headers = [('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'), ('referer', url)]
	content = Read_It(link,headers)
	url 	= re.findall('sources: [[][{]file:"(.+?)"[}],',content)
	#url 	= re.compile('sources: [[][{]file:"(.+?)"[}],').findall(content)
	url = ''.join(url)
	if 'label:"720p"' in url:
		m = re.findall('(?s)(".+?$)',url)
		#m = re.compile('(".+?$)').findall(url)
		m= ''.join(m)
		url = url.replace(str(m),'')
	if not url:
		#url 	= re.compile('sources: [[][{]file:"(.+?)v.mp4"').findall(content)
		url 	= re.findall('sources: [[][{]file:"(.+?)v.mp4"',content)
		url = ''.join(url)
		url=url+'v.mp4'
	url 	= ''.join(url)
	url 	= str(url)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'
	#xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	Player(url,title,thumb)

def Player(url,title,thumb):

	lis	= xbmcgui.ListItem(title,iconImage=thumb,thumbnailImage=thumb)
	lis.setInfo(type='Video', infoLabels ={'Title':title})
	lis.setPath(url)
	player.play(url, lis)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	for i in range(0, 120):
		if player.isPlayingVideo(): break
		xbmc.sleep(1000)
	while player.isPlaying():
		xbmc.sleep(2000)
	xbmc.sleep(4000)

def Play_es(content,url,title,thumb):
	#xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	#link 	= re.compile('https:[/][/]estream(.+?)"').findall(content)
	link 	= re.findall('https:[/][/]estream(.+?)"',content)
	link 	= 'https://estream'+''.join(link)
	headers = [('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'), ('referer', url)]
	content = Read_It(link,headers)
	#url 	= re.compile('<source src=[\"](.+?)[\"] type=[\']application[/]x-mpegURL[\'] [/]>').findall(content)
	url 	= re.findall('<source src=[\"](.+?)[\"] type=[\']application[/]x-mpegURL[\'] [/]>',content)
	url 	= ''.join(url)
	url 	= str(url)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'
	#xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	Player(url,title,thumb)



def Cloud_up(content,url,title,thumb):
	#xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	#link 	= re.compile('http:[/][/]cloudupload(.+?)"').findall(content)
	link 	= re.findall('http:[/][/]cloudupload(.+?)"',content)
	link 	= 'http://cloudupload'+''.join(link)
	headers = [('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'), ('referer', url)]
	content = Read_It(link,headers)
	url 	= re.findall('<source src=[\"](.+?)[\"] type=[\']video[/]mp4[\']',content)
	#url 	= re.compile('<source src=[\"](.+?)[\"] type=[\']video[/]mp4[\']').findall(content)
	url 	= ''.join(url)
	url 	= str(url)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'
	#xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	Player(url,title,thumb)

def Play_king(content,url,title,thumb):
	#xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	#link 	= re.compile('https:[/][/]kingvid(.+?)"').findall(content)
	link 	= re.findall('https:[/][/]kingvid(.+?)"',content)
	link 	= 'https://kingvid'+''.join(link)
	headers = [('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'), ('referer', url)]
	content = Read_It(link,headers)
	#url 	= re.compile('src="(.+?)[/]\w+[/](?:[\s\S]+?)[|]([a-z]\w{40,100})[|]').findall(content)
	url 	= re.findall('src="(.+?)[/]\w+[/](?:[\s\S]+?)[|]([a-z]\w{40,100})[|]',content)
	for i in url:
		link = i[0]+i[1]+'/v.mp4'
	url 	= ''.join(url)
	url 	= str(url)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'
	#xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	Player(url,title,thumb)

# def RESOLVE(url):
#     #print '>>>>>>>>>>>>>>>>>>>>>>' + url + '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
#     try:
#         if 'speedvid.net' in url:
#             OPEN = Open_Url(url)
#             link = re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|',re.DOTALL).findall(OPEN)
#             for port,server,hash in link:
#                 url = 'http://'+ server +'.speedvid.net:'+port+'/'+hash+'/v.mp4'
#                 url =  url.replace(str(embed),'sn')
#                 url = ''.join(url)

#             stream_url=url


#         elif 'watchpinoymoviesonline.info' in url:
#             OPEN = Open_Url(url)
#             url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
#             stream_url = urlresolver.resolve(url)
#         else:
#             stream_url = urlresolver.resolve(url)
#             liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
#             liz.setInfo(type="Video", infoLabels={"Title": description})
#             liz.setProperty("IsPlayable","true")
#             liz.setPath(stream_url)
#             xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
#     except:
#         xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)") 





params = Get_Params()
mode = None

try: mode = params['mode']
except: pass
try: url = params['url']
except: pass
try: title = params['title']
except: pass
try: thumb = params['iconimage']
except: pass
if mode == None or len(sys.argv[2])<2: Menu(url)

elif mode == 'searc': 
	content = Search()
	Results(content)
elif mode == 'csear':
	content = Read_It(url,headers)
	Results(content)
elif mode == 'page2':
	content,res = Check(url,headers)
	if res == 'cloud':
		RESOLVE(url)
	elif res == 'vid': 
		RESOLVE(url)
	elif res == 'shagged':
		url = 'http://www.pinoyrewind.info/'
		Menu(url)
	

elif mode == 'page':
	content,res = Check(url,headers)
	if res == 'cloud':
		Cloud_up(content,url,title,thumb)
	if res == 'vid':
		#RESOLVE(url)
		Play_vid(content,url,title,thumb)
		#Cloud_up(content,url,title,thumb)
	elif res == 'speed':
		Speedvid(content,url,title,thumb)
	elif res == 'es': 
		Play_es(content,url,title,thumb)
	elif res == 'king': 
		Play_king(content,url,title,thumb)
	elif res == 'shagged':
		url = 'http://www.pinoyrewind.info/'
		Menu(url)

if mode == 'WS':
    mp = [
         ('IPAGLABAN MO','http://www.pinoyrewind.info/search/label/Ipaglaban%20Mo?max-results=24','https://4.bp.blogspot.com/-2yYzNwLg4LU/U5LMCkMElaI/AAAAAAAAD2U/bCwj9bOnSmA/w260/ipaglabanmo.jpg'),
         ('MAALAALA MO KAYA','http://www.pinoyrewind.info/search/label/MMK?max-results=24','https://3.bp.blogspot.com/--SWMeRoqms0/V1QwuUUel_I/AAAAAAAAABQ/nFiDRdur128QBODQaj0CpqelchR1y1n4wCLcB/w260/mmk.jpg'),
         ('WANSAPANATAYM','http://www.pinoyrewind.info/search?q=WANSAPANATAYM&max-results=24','https://2.bp.blogspot.com/-da4J7x5yTEw/Tn6oj4LiUrI/AAAAAAAAAJc/Ld2nWLyKmjI/w260/Wansapanataym%2BSeptember%2B24%252C%2B2011.jpg'),
         ('MATANGLAWIN','http://www.pinoyrewind.info/search/label/Matanglawin?max-results=24','https://4.bp.blogspot.com/_Kd2gmvytCDI/SeGZeKnss7I/AAAAAAAAA2s/_7QtI5UY3ho/w260/matanglawin031908.jpg')    
         ]
    for i in mp:  
        xbmc.log('################## '+str(i),2)
        #add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
        #add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR]',i[1],fanart)
        add_dir('f','csear',i[1],'[COLOR yellow]'+i[0]+'[/COLOR]',i[2],fanart)
        xbmc.executebuiltin('Container.SetViewMode(55)') 

#'VARIETY/REALITY'
if mode == 'VS':
    mp = [
         ('ASAP','http://www.pinoyrewind.info/search/label/ASAP?max-results=24','https://1.bp.blogspot.com/-QqpWlgyF8MU/VXPrSAgc_uI/AAAAAAAAACk/bUz7G_TGat8/w260/asap20.jpg'),
         ('ITS SHOWTIME','http://www.pinoyrewind.info/search/label/It%27s%20Showtime?max-results=24','https://4.bp.blogspot.com/-IA6TnANKolA/VO7ChHspb6I/AAAAAAAAACg/sqCkSiaZKfM/w260/its%2Bshowtime.jpg'),
         ('GGV','http://www.pinoyrewind.info/search/label/Gandang%20Gabi%20Vice?max-results=24','https://1.bp.blogspot.com/-ne0XAtrJpJw/VlIYXtHKISI/AAAAAAAAAEo/zm6PH_oTZmI/w260/ggvuncut.jpg'),
         ('MAGANDANG BUHAY','http://www.pinoyrewind.info/search/label/Magandang%20Buhay?max-results=24','https://1.bp.blogspot.com/--9jgdU9Nk0U/VxSLSiSJo-I/AAAAAAAAARg/Qhd5GUUUR3o2Wv1837ppirI5gnvBiiq9ACLcB/w260/mb.jpg'),
         ('TONIGHT WITH BOY ABUNDA','http://www.pinoyrewind.info/search/label/Tonight%20with%20Boy%20Abunda?max-results=24','https://4.bp.blogspot.com/-53HH_Du83zM/Vgl3DCnayNI/AAAAAAAAALI/SoqOArpSw1U/w260/TWBA.jpg'),
         ('LITTLE BIG SHOTS','http://www.pinoyrewind.info/search/label/Little%20Big%20Shots?max-results=24','https://2.bp.blogspot.com/-yTEC8TWxnYA/WY73bMaVwSI/AAAAAAAAAS8/A8wM6XtgEe8yp4kjt6jQA4kW-7HzUcoPgCLcBGAs/w260/lbs.jpg'),
         ('I CAN SEE YOUR VOICE', 'http://www.pinoyrewind.info/search/label/I%20Can%20See%20Your%20Voice?max-results=24', 'https://2.bp.blogspot.com/-Ew24VShXegc/Wb5QGMw1geI/AAAAAAAAATw/x1Y04VXJt80Fqf-yUNB8B1aQdPLmxBUVACLcBGAs/w260/icsyv.png')
          ]
    for i in mp:  
        xbmc.log('################## '+str(i),2)
        #add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
        #add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR]',i[1],fanart)
        add_dir('f','csear',i[1],'[COLOR yellow]'+i[0]+'[/COLOR]',i[2],fanart)
        xbmc.executebuiltin('Container.SetViewMode(55)') 

#'COMEDY'
if mode == 'CMY':
    mp = [
         ('BANANA SUNDAE','http://www.pinoyrewind.info/search/label/Banana%20Sundae?max-results=24','https://1.bp.blogspot.com/-iE_mY3Bzwh0/VmQYKdZcSRI/AAAAAAAAAFo/2998wSuCBpo/w260/bs.jpg'),
         ('GOIN BULILIT','http://www.pinoyrewind.info/search/label/Goin%27%20Bulilit?max-results=24','https://3.bp.blogspot.com/-iNIuesVCoFY/VFYkWcMub7I/AAAAAAAAAnk/xRgLZ7j9iSQ/w260/goinbuliliy.jpg'),
         ('HOME SWEETIE HOME','http://www.pinoyrewind.info/search/label/Home%20Sweetie%20Home?max-results=24','https://2.bp.blogspot.com/-PeEp5OVNWvc/V25x4kE2DDI/AAAAAAAAACQ/6NNw7u5-ZzMTT6t_-8m1oy54ebAVARPlgCLcB/w260/hsh.png')         
         ]
    for i in mp:  
        xbmc.log('################## '+str(i),2)
        #add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
        #add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR]',i[1],fanart)
        add_dir('f','csear',i[1],'[COLOR yellow]'+i[0]+'[/COLOR]',i[2],fanart)
        xbmc.executebuiltin('Container.SetViewMode(55)') 

#NEWS CURRENT AFFAIRS
if mode == 'NCP':
    mp = [
         ('TV PATROL','http://www.pinoyrewind.info/search/label/TV%20Patrol?max-results=24','https://3.bp.blogspot.com/-UPzRhNEdrBo/VYHLYaBIJNI/AAAAAAAAABI/NSbHFJRK8ak/w260/tvp.jpg'),
         ('TV PATROL WEEKEND','http://www.pinoyrewind.info/search?q=tv+patrol+weekend&max-results=24','https://1.bp.blogspot.com/-vfSvcaGhoDE/VYHL_9uyjhI/AAAAAAAAABQ/RB6rAIh6pVo/w260/tvpw.jpg'),
         ('RATED K','http://www.pinoyrewind.info/search/label/Rated%20K?max-results=24','https://4.bp.blogspot.com/-0qxkn5ZqFIE/VXPuNX66oUI/AAAAAAAAACw/wP4zk-zqKwU/w260/rK.jpg'),
         ('FAILON NGAYON','http://www.pinoyrewind.info/search/label/Failon%20Ngayon?max-results=24','https://3.bp.blogspot.com/-1tb6wEUu26c/UYUK_1V1tKI/AAAAAAAAuuA/fLjq_Nnpk70/w260/FAILON+NGAYON+ABS.jpg'),             
         ('SOCO','http://www.pinoyrewind.info/search/label/SOCO?max-results=24','https://3.bp.blogspot.com/-5S75EFPBOsY/VXKYSzuPeeI/AAAAAAAAACI/p044BVjqb2k/w260/ocos.jpg') 
         ]
    for i in mp:  
        xbmc.log('################## '+str(i),2)
        #add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
        #add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR]',i[1],fanart)
        add_dir('f','csear',i[1],'[COLOR yellow]'+i[0]+'[/COLOR]',i[2],fanart)
        xbmc.executebuiltin('Container.SetViewMode(55)') 
 
if mode == 'ABS':
    mp = [
         ('ANG PROBINSYANO', 'http://www.pinoyrewind.info/search/label/Ang%20Probinsyano?max-results=50', 'https://2.bp.blogspot.com/-oTcXT51yhV4/Vgg0Cl13G3I/AAAAAAAAAK4/vFH9kU-asck/w260/fpj.jpg'),
         ('LA LUNA SANGRE', 'http://www.pinoyrewind.info/search/label/La%20Luna%20Sangre?max-results=50', 'https://3.bp.blogspot.com/-llWtWea4Gk8/WUe_rlZUWAI/AAAAAAAAARE/eknMjM39CNsbEDllycOKRAqyzPxcexTCgCLcBGAs/w260/lls.jpg'),
         ('HANGGANG SAAN', 'http://www.pinoyrewind.info/search/label/Hanggang%20Saan?max-results=50', 'https://2.bp.blogspot.com/-9Y2o40gl8WY/Whvlke3d9_I/AAAAAAAAAV4/sNVqB0IKHb4MtZas7dh1W3JJsHy-tYApwCLcBGAs/w260/hs.jpg'),
         ('WILDFLOWER', 'http://www.pinoyrewind.info/search/label/Wildflower?max-results=50', 'https://3.bp.blogspot.com/-MzfXOsD0_C4/WKGLFD7SRXI/AAAAAAAAANg/UbdYxheTTJUO4mIkXa4M-tsfAf_B6J2GACLcB/w260/wf.jpg'),
         ('A PROMISE OF FOREVER', 'http://www.pinoyrewind.info/search/label/The%20Promise%20of%20Forever?max-results=50', 'https://3.bp.blogspot.com/-wBs5kKv-i0s/WbZS9ywEXtI/AAAAAAAAATg/XK4wiQdVS7IDjp6q8rB6YhXtI0NQyA0qACLcBGAs/w260/tpof.jpg'),
         ('THE GOOD SON', 'http://www.pinoyrewind.info/search/label/The%20Good%20Son?max-results=50', 'https://2.bp.blogspot.com/-AKYkOw3v3hA/WckdCEtYsGI/AAAAAAAAAUU/iy36hyzr4BwRzZmFL-wDcHk768zwx7p-wCLcBGAs/w260/tgs.jpg'),
         ('PUSONG LIGAW', 'http://www.pinoyrewind.info/search/label/Pusong%20Ligaw?max-results=50', 'https://3.bp.blogspot.com/-GHi010Tdco8/WP24jSPpsvI/AAAAAAAAAPU/L1SPh6CXEi0FFV-xxSyrDj6U8dai7jEKwCLcB/w260/pl.jpg'),
         ('IKAW LANG ANG IIBIGIN', 'http://www.pinoyrewind.info/search/label/Ikaw%20Lang%20Ang%20Iibigin?max-results=50', 'https://2.bp.blogspot.com/-kX2w-3hOjMo/WQbgh2qViuI/AAAAAAAAAPk/L1vNcES4td0mk3mhO0FaZF9exbalYJJUQCLcB/w260/ilai.jpg'),
         ('LEGEND OF THE BLUE SEA', 'http://www.pinoyrewind.info/search/label/Legend%20of%20the%20Blue%20Sea?max-results=50', 'https://3.bp.blogspot.com/-Rr2SjZ_HiOI/WRCOQRzGJEI/AAAAAAAAAQU/aENCgO53b7c2g7L3W9sJYNXKjx62NUCuwCLcB/w260/lotbs.jpg'),
         ('MY DEAREST INTRUDER', 'http://www.pinoyrewind.info/search/label/My%20Dearest%20Intruder?max-results=50', 'https://4.bp.blogspot.com/-8wjZtkcwxx4/Wcjk6UmrdoI/AAAAAAAAAUA/sAaehT0W9BAUVenqsQAyHV8_0UQwhUOcACLcBGAs/w260/mdi.jpg'),
         ('HWARANG','http://www.pinoyrewind.info/search/label/Hwarang?max-results=24','https://3.bp.blogspot.com/-K2ffqJr5Ehg/Wfdxci9bQMI/AAAAAAAAAUo/UQD11EE0yWg4T5R-abW01R6ANLAMn3b1QCLcBGAs/w260/hwrng.jpg'),
         ('ON THE WINGS OF LOVE', 'http://www.pinoyrewind.info/search?q=ON+THE+WINGS+OF+LOVE&max-results=24', 'http://4.bp.blogspot.com/-Zi4JVlrzH_k/Vch8uyWGmjI/AAAAAAAAAHs/YFCzc3WxxF4/w260/on%2Bthe%2Bwings.jpg'),
         ('A LOVE TO LAST', 'http://www.pinoyrewind.info/search?q=A+LOVE+TO+LAST&max-results=24', 'https://2.bp.blogspot.com/-BhenMNwlEC0/WHNuA6f2IWI/AAAAAAAAAMs/Z5lMnmkWakwEhioKfxsVMbvKUwxc3EUlgCLcB/w260/altl.jpg'),
         ('DOLCE AMORE','http://www.pinoyrewind.info/search?q=DOLCE+AMORE&max-results=50','https://3.bp.blogspot.com/-Rz2nVMhbnto/VsP_jdZgIPI/AAAAAAAAAJ4/R3fuhASOkyk/w260/dolamo.jpg')             
         ]       

    for i in mp:  
        xbmc.log('################## '+str(i),2)
        #add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
        #add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR]',i[1],fanart)
        add_dir('f','csear',i[1],'[COLOR yellow]'+i[0]+'[/COLOR]',i[2],fanart)
        xbmc.executebuiltin('Container.SetViewMode(55)') 
#if mode == 'NEWS'

if mode == 'latest':
	cont = Read_It('http://www.pinoyrewind.info/search/label/ABS-CBN?&max-results=24',headers)
	main = Get_From_To(cont, "<div class='blog-posts hfeed'>", "<span id='blog-pager-older-link'>")
	#matches = re.compile('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];').findall(main)
	matches = re.findall('(?s)href=[\'](.+?)[\'](?:.+?)[(]"(.+?)","(.+?)["\|&](?:.+?);(.+?)"[)][)];',main)
	for i in matches: 
		t = ''.join(i[2])
		if len(t) > 25 : 
			t = t[:35]
		zx = ''.join(i[3])
		if 'div class=' in zx : zx = ''
		add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR][COLOR white] '+zx+' [/COLOR]',i[1],fanart)
	if "<a class='blog-pager-older-link' href=" in cont:
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(cont)
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",cont)
		url = ''.join(url)
		add_dir('f','csear',url,'[COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR]',icon,fanart)

if mode == 'movie':
	url = 'http://www.pinoyrewind.info/search/label/Film?&max-results=50'
	content = Read_It(url)
	main = Get_From_To(content, "<div class='blog-posts hfeed'>", "<span id='blog-pager-older-link'>")
	matches = re.findall("(?m)href='(.+?)'>$[\s\S]+?[(]\"(.+?)\",\"(.+?)\"",main)
	#matches = re.compile("(?m)href='(.+?)'>$[\s\S]+?[(]\"(.+?)\",\"(.+?)\"").findall(main)
	for i in matches: 
		t = ''.join(i[2])
		if len(t) > 25 : 
			t = t[:35]
		add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR]',i[1],fanart)
	if "<a class='blog-pager-older-link' href='" in content:
		url = re.findall("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link",content)
		#url = re.compile("(?s)<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link").findall(content)
		url = ''.join(url)
		add_dir('f','csear',url,'[COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR]',icon,fanart)

xbmcplugin.endOfDirectory(addon_handle)