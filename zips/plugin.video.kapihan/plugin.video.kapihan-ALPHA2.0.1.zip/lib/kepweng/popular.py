# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests, xbmcvfs
import re, os 
#import urlresolver
#import resolveurl as resolveurl
#import jsunpack

#from addon.common.addon import Addon
#import json
#import time

#import urlparse
#import __builtin__

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
read_pb = requests.get('https://pastebin.com/raw/gjN94ax1', verify=False, headers=headers)
html_pb = read_pb.content
#xbmc.log('PB######################################################### '+str(html_pb),2)
	

#PASTEBIN REGEX BLOCK
#main_regex = re.compile('<ofwshow_regex>(.+?)</ofwshow_regex>',re.DOTALL).findall(html_pb)[0]
#xbmc.log('PB######################################################### '+str(main_regex),2)

#block1 = re.compile('<regex_main>(.+?)</regex_main>',re.DOTALL).findall(str(main_regex))[0]
#block2 = re.compile('<regex_submain>(.+?)</regex_submain>',re.DOTALL).findall(str(main_regex))[0]

#matches = re.compile('<match>(.+?)</match>',re.DOTALL).findall(str(main_regex))[0]
#np_block = re.compile('<np>(.+?)</np>',re.DOTALL).findall(str(main_regex))[0]
#np_phtv = re.compile('<np_phtv>(.+?)</np_phtv>',re.DOTALL).findall(str(main_regex))[0]
#NEXTPAGE
#np = re.compile('<np>(.+?)</np>',re.DOTALL).findall(html_pb)[0]
#xbmc.log('npblock######################################################### '+str(np_block),2)

#USERDATA_PATH = xbmc.translatePath('special://home/addons/')
#XBMCAddon
USERDATA_PATH = xbmcvfs.translatePath('special://home/addons/')
#ADDON_DATA = os.path.join(USERDATA_PATH,'script.module.kepwengnews')
#Log_file = os.path.join(ADDON_DATA,'Import_Log.txt')
#error_file = os.path.join(ADDON_DATA,'ErrorLog.txt')

# def send_log(scraper_data, optional = ''):

# 	if not os.path.exists(Log_file):
# 		full_write = open(Log_file,"w")

# 	elif os.path.exists(Log_file):
# 		full_write = open(Log_file,'a')	
	
# 	Print = '<##########################################################################################\
# 			\n##  query data: '+str(optional)\
# 			+'\n##  Data with: '+str(scraper_data)\
# 			+'\n#########################################################################################>' 
# 	full_write.write(Print+'\n')




# def send_log_error(scraper_data, optional = ''):
# 	if not os.path.exists(error_file):
# 		error_write = open(error_file,"w+")
# 	elif os.path.exists(error_file):
# 		error_write = open(error_file,'a')
	
# 	Print = '<##########################################################################################\
# 			\n##  query data: '+str(optional)\
# 			+'\n##  Data with: '+str(scraper_data)\
# 			+'\n#########################################################################################>' 
# 	error_write.write(Print+'\n')


def replace_unicode(text):
	text = text.replace('&#7424;','A').replace('&#665;','B').replace('&#7428;','C').replace('&#7429;','D').replace('&#7431;','E').replace('&#1171;','F').replace('&#610;','G').replace('&#668;','H').replace('&#618;','I').replace('&#7434;','J').replace('&#7435;','K').replace('&#671;','L').replace('&#7437;','M').replace('&#628;','N')\
	.replace('&#7439;','O').replace('&#7448;','P').replace('&#42927;','Q').replace('&#640;','R').replace('&#42801;','S').replace('&#7451;','T').replace('&#7452;','U').replace('&#7456;','V').replace('&#7457;','W').replace('&#120;','X').replace('&#655;','Y').replace('&#7458;','Z')
	return text





#send_log(block2,'BLOCK2')

def scrape_details(url):
	#send_log(url,'URL')	
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	html = html.decode('utf-8')

	regexme = r'<div class="details">(.+?)<div class="slider-star">'	
	list_match = re.compile(regexme,re.DOTALL).findall(html)

	regexme2 = r'<div class="img">.+?<img src="(.+?)".+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>'
	list_match2 = re.compile(regexme2,re.DOTALL).findall(str(list_match))
	#send_log(list_match,'MAINBLOCK OFW HTML')

	sources = []

	for icon,title,description,status in list_match2:
		description = description
		title = title + ' ([COLOR yellow] STATUS: [/COLOR]' + '[COLOR red]'+status +'[/COLOR])'		
		source = '<name>'+title+'</name><icon>'+icon+'</icon><summary>'+description+'</summary><status>'+status+'</status>'
		sources.append(source)
	# 	send_log(sources,'SOURCES')	

	
	#try:
	#	npblock = re.compile(np_block,re.DOTALL).findall(html)[0]
	#	url = '<nextpage>nextpage/'+npblock+'</nextpage>'
		#send_log(url,'NEXTPAGE URL')
	#	sources.append(url)
	#except:pass
	return sources

	
	

def scrape_links(url):
	#xbmc.log('URLNOW######################################################### '+str(url),2)	
	#pd = xbmcgui.DialogProgress()
	#pd.create('Please Wait ...Dont Cancel')
	sources = []

	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content




	#player code below
	getplayer = re.compile('<div id="player">(.+?)</script>',re.DOTALL).findall(html)
	getformdata = re.compile('get_player\("(.+?)","(.+?)"\)',re.DOTALL).findall(str(getplayer))
	
	for url_post,thumb in getformdata:
		url_post = url_post
		thumb = thumb
		#send_log(url_post,'OFW DATA')
		#send_log(thumb,'OFW DATA')

	new_headers = {'authority':'ofwshow.ru',
				'origin':'https://ofwshow.ru',
				'Referer':url,
				'x-requested-with': 'XMLHttpRequest',
				'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}

	post_player = 'https://ofwshow.ru/function.php'

	data = {'url': url_post,
			'thumb':thumb}
	
	get_player_source = requests.post(post_player, data = data, headers = new_headers)
	player_data = get_player_source.content

