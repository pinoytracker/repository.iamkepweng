import xbmc, xbmcgui, xbmcplugin, xbmcaddon, requests
import re, os, sys

#import koding
#import koding.router as router
#from koding import route

#addon_handle    = int(sys.argv[1])

headers_pastebin = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
Read_PopupNews = requests.get('https://pastebin.com/raw/eXbb44Yy', headers=headers_pastebin)
PasteBin_PopupNews = Read_PopupNews.content


def popup():
    #message=Open_Url(newsinfo)
    #headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
    #Readit = requests.get(newsinfo, headers=headers)
    #message = Readit.content 
    
    if len(PasteBin_PopupNews)>1:
        path = xbmcaddon.Addon().getAddonInfo('path')
        comparefile = os.path.join(os.path.join(path,''), 'balita.txt')
        r = open(comparefile)
        compfile = r.read()
        #xbmc.log('COMFILE##################'+str(compfile),2)       
        if compfile == PasteBin_PopupNews:pass
        else:
            showText('[B][COLOR gold]IMPORTANT PINOY REPLAY NEWS[/COLOR][/B]', PasteBin_PopupNews)
            text_file = open(comparefile, "w")
            text_file.write(PasteBin_PopupNews)
            text_file.close()

def showText(heading, text):

    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            quit()
            return
        except: pass

if __name__ == '__main__':
    popup()