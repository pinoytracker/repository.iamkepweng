import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon
#import urlresolver
import resolveurl as urlresolver
from addon.common.addon import Addon
from lib import cfscrape

import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.pinoykoditeamkepweng'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
player          = xbmc.Player()
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'TELEPINOY'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
sourceUrl = 'http://pinoykodigroup.site/kepweng/source_serye.xml'


BASEURL = 'https://pinoypediamovie.se/'
BASEURL2 = 'http://watchpinoymoviesonline.info/'
BASEURL3 = 'http://www.kapuso.be/'
purl     = 'http://www.pinoyakotv.info/category/sports/pba/'
dialog = xbmcgui.Dialog()

def MENU():
    OPEN = Open_Url(sourceUrl)
    Regex = re.compile('<passwordphrase>(.+?)<passwordphrase>',re.DOTALL).findall(OPEN)
    for source in Regex:
        kb = xbmc.Keyboard(None, 'Enter Password')
        kb.doModal()
        if (kb.isConfirmed()):
            st = kb.getText()
            sagot = source
            if st == sagot: 
            #dialog.ok('yes')
                MENU2()
            else:
                dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE')
                mode = None
                MENU()
        else:
            xbmc.executebuiltin('Activatewindow(home)')
    
    
    #code here with input
    #OPEN = Open_Url(sourceUrl)
    #Regex = re.compile('<passwordphrase>(.+?)<passwordphrase>',re.DOTALL).findall(OPEN)
    #xbmc.log('USERNAMESSSSSS##################'+str(UserName),2)
    #for source in Regex:
    #    Sgot = source
    #    UserName = ADDON.getSetting('UserName')
    #    Password = ADDON.getSetting('Password')
    #    Sagot2 = 'Pin0yKodi'
        #xbmc.log('USERNAMESSSSSS##################'+str(Sagot2),2)
    #    if UserName == Sgot and Password == Sagot2:
            #dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE')
    #        MENU2()
    #    else:
    #        dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE CHANGE THE USERNAME PASSWORD IN THE SETTINGS')
    #        mode = None
    #        exit()

def MENU2():
    #xbmcgui.Dialog().ok("Bangon Pinoy", "Gawang pinoy Tubong La Union", "ALLAN")
    addDir('[B][COLOR white]ABS-CBN KAPAMILYA[/COLOR][/B]','http://pacitalaflakes.blogspot.com/search/label/ABS-CBN?m=0',5,ICON,FANART,'')
    addDir('[B][COLOR white]GMA KAPUSO[/COLOR][/B]',BASEURL3 + 'search/label/GMA?&max-results=24',5,ICON,FANART,'')
    addDir('[B][COLOR white]LAMBINGAN[/COLOR][/B]','http://www.lambingan.su/blog/',30,ICON,FANART,'')
    addDir('[B][COLOR white]PBA REPLAY[/COLOR][/B]','http://www.pinoyakotv.info/category/sports/pba/',20,ART + 'icon',FANART,'')
    
    addDir('[B][COLOR white]FILIPINO MOVIES [/COLOR][/B]',BASEURL2+'category/latest/',24,ICON,FANART,'')
    addDir('[B][COLOR white]FILIPINO MOVIES 2[/COLOR][/B]','https://pinoypediamovie.se/category/pinoy-movies/',90,ICON,FANART,'')
    addDir('[B][COLOR white]TAGALOG-DUBBED[/COLOR][/B]',BASEURL2+'category/tagalog-dubbed/',24,ICON,FANART,'')
    addDir('[B][COLOR white]ASIAN MOVIES[/COLOR][/B]',BASEURL+'/category/asian-movies/',90,ICON,FANART,'')
    #addDir('[B][COLOR white]HOLLYWOOD MOVIES[/COLOR][/B]','url',3,ART + 'hmov.jpg',FANART,'')
    addDir('[B][COLOR white]HOLLYWOOD MOVIES[/COLOR][/B]',BASEURL+'/category/hollywood-movies/',90,ICON,FANART,'')
    addDir('[B][COLOR white]HOLLYWOOD BLURAY[/COLOR][/B]',BASEURL+'/category/bluray/',90,ICON,FANART,'')
    
    
    
    addDir('[B][COLOR white]SEARCH[/COLOR][/B]','url',93,ART + 'serch.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(55)')

    #setView('tvshows', 'tvshows-view')

def PinoyMov_Menu(url):
    #OPEN = Open_Url(url)
    scrapers = cfscrape.create_scraper()
    OPEN = scrapers.get(url).content
  
    Regex = re.compile('div id="content" role="main">(.+?)<!-- end #content -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,ART + 'fanart2.jpg','')
    np = re.compile('rel="next".+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,20,ART + 'n_p.jpg',ART + 'fanart2.jpg','')
    #setView('tvshows', 'default-view') 
    

    
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<a class='thumbx' href='(.+?)' title='(.+?)'.+?src='(.+?)'/></a>",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        icon = icon.replace('s72-c/','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'kapuso' in url:
            icon = ART + 'nextpagekap.jpg'
        if 'pacitalaflakes' in url:
            icon = ART + 'nextpagetamb.jpg'
        addDir('[B][COLOR red]Older Posts>>>[/COLOR][/B]',url,5,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(55)')

def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    altlinks = re.compile('DM.player.+?"player(.+?)".+?video: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
        addDir('[B][COLOR white]Part %s[/COLOR][/B]' %name2,'http://www.dailymotion.com/embed/video/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(55)')


#------------------###############tagalog movie###########

#def pinoyonlinemenu():
 
#    setView('tvshows', 'tvshows-view')
def PBALINKS(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe width="100%".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<h3>(.+?)</h3>.+?<iframe frameborder="0".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    #http://3.bp.blogspot.com/--G_j-M9lx8w/Wo7h75ZOWKI/AAAAAAAAqMM/IL-C_aOm7wc3tGpD1XFtoNe2Y3UFTY9swCLcBGAs/s1600/pba-philippine-cup-2017.jpg
    #counter = 0
    for url in Regex:
        if 'http' not in url:
        #counter = counter + 1
        
            url = 'http:' + url
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            #name3 = counter
        except:pass

        #xbmc.log('MATCHES######################################################################################## '+str(icon),2)
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,iconimage,'')

    for name,url in Regex2:
        
        if 'http' not in url:
        #counter = counter + 1
        
            url = 'http:' + url
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            #name3 = counter
        except:pass

        #xbmc.log('MATCHES######################################################################################## '+str(url),2)
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,iconimage,'')
    
    
    np = re.compile('<a class="nextpostslink" rel="next" href="(.+?)">&raquo;</a>',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,20,ART + 'n_p.png',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(55)')

def Mov_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h1 class="archive-title">PBA Archive</h1>(.+?)<div class=\'wp-pagenavi\'>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a class="entry-thumbnails-link" href="(.+?)"><img src="(.+?)" alt="(.+?)SHOW DESCRIPTION.+?title="(.+?)" />',re.DOTALL).findall(str(Regex))
    #http://3.bp.blogspot.com/--G_j-M9lx8w/Wo7h75ZOWKI/AAAAAAAAqMM/IL-C_aOm7wc3tGpD1XFtoNe2Y3UFTY9swCLcBGAs/s1600/pba-philippine-cup-2017.jpg
    for url,icon,desc,name in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
        icon = 'http:' + icon
        #xbmc.log('MATCHES######################################################################################## '+str(icon),2)
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,23,icon,icon,desc)
    
    np = re.compile('<a class="nextpostslink" rel="next" href="(.+?)">&raquo;</a>',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,20,ART + 'n_p.png',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(55)')
    
def live_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="item-video".+?href="(.+?)".+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon in Regex:
        if 'http' not in icon:
            icon = 'http:' + icon
        name = url.split('//')[1]
        name = name.split('/')[1].replace('-',' ').replace('live streaming','(Stream) ').title()
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,80,icon,ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(55)')

def cats_mov(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="sub-menu">(.+?)<!-- end #main-nav -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'Ghost Fighter' not in name:
            if 'Slam Dunk' not in name:
                if 'Pinoy Classic' not in name:
                    if 'Latest' not in name:
                        if 'Live Stream' not in name:
                            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,20,ART + 'genre.jpg',ART + 'fanart2.jpg','')   

def res_live(url):
    OPEN = Open_Url(url)
    if '//livestream01' in OPEN:
       url = re.compile('var video="(.+?)"',re.DOTALL).findall(OPEN)[0]
    elif 'file: ' in OPEN:
        try:
            url = re.compile('file: "(.+?)"',re.DOTALL).findall(OPEN)[0]
        except:
            url = re.compile("file: '(.+?)'",re.DOTALL).findall(OPEN)[0]
    else:
        url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
        url = url.replace('?autoplay=1&wmode=opaque&rel=0&showinfo=0&modestbranding=0','')
    url1 = urlresolver.resolve(url)
    if url1:
        try:
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url1)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except: pass
    else:
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
        
        

############.pinoymoviepedia.SU###########
#def moviechannel():
#    setView('tvshows', 'tvshows-view')
    
def pinoypedia_content(url):
    xbmc.log('PINOYPEdia##################################################################################### '+str(url),2)
    OPEN = Open_Url(url)
    Regex = re.compile('<li class="border-radius.+?src="(.+?)".+?href="(.+?)" title="(.+?)">',re.DOTALL).findall(OPEN)
    
    for icon,url,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        icon = icon.replace('-210x142','').replace('-199x142','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,95,icon,ART + 'fanart2.jpg','')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page >>>[/COLOR][/B]',url,90,ART + 'n_p2.png',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(55)')

def pinoypedia_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('tag menu-item.+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,90,ART + 'fil-tv.png',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(55)')
    
def pinoypedia_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('data-lazy-src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        url = url.replace('https://href.li/?','')
        if urlresolver.HostedMediaFile(url).valid_url():
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    altlinks = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in altlinks:
        if 'dailymotion' in altlinks:
            url = 'http:' + url
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    xbmc.executebuiltin('Container.SetViewMode(55)')

def pedia_Search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL + '/?s=' + search
            pinoypedia_content(url)


#############PLAYER#################
def Player(url,name,iconimage):

    lis = xbmcgui.ListItem(name,iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    lis.setInfo(type='Video', infoLabels ={'Title':description})
    lis.setPath(url)
    player.play(url, lis)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
    for i in range(0, 120):
        if player.isPlayingVideo(): break
        xbmc.sleep(1000)
    while player.isPlaying():
        xbmc.sleep(2000)
    xbmc.sleep(4000)


    

    
############### lambingan.########### 
def lamb_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h2>Blog</h2>(.+?)div class="pagination">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('(?s)<div class="item-header">.+?<img src=.+?rel="(.+?)".+?</div><div class="item-content"><h3><a href="(.+?)">(.+?)</a></h3>',re.DOTALL).findall(str(Regex))
    for icon,url,name in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        if 'http' not in icon:
            icon = 'http:' + icon
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,35,icon,icon,'')
    np = re.compile('(?s)<a class="next page-numbers" href="(.+?)"><i class=',re.DOTALL).findall(OPEN)
    for url in np:
        #xbmc.log('NEXTPAGE######################################################################################## '+str(url),2)

        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,30,ART + 'lampnp.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(55)')
    
def lamb_vids(name,url):
    #xbmc.log('MAIN######################################################################################## '+str(url),2)
    
    OPEN = Open_Url(url)
    xbmc.log('MAINURL######################################################################################## '+str(url),2)
    main = re.compile("<br /> <span style=\"(.+?)<strong>Category</strong>",re.DOTALL).findall(OPEN)
    xbmc.log('MAIN##################################################################################### '+str(main),2)
    Regex = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(str(main))
    #Regexdatum = re.compile('<h2>(.+?)</h2>',re.DOTALL).findall(str(main))

    #desc = re.compile('<h2>(.+?)</h2>',re.DOTALL).findall(OPEN)
    #xbmc.log('MAIN######################################################################################## '+str(main),2)

    if 'CLICK 3-4 TIMES TO PLAY' in OPEN:
        #for datum2 in Regexdatum:
        #    datum2 = datum2
        #addDir(name,url,mode,iconimage,fanart,description):
        addDir('[B][COLOR white]~~~ CHOOSE LINK BELOW[/COLOR][/B]',url,35,iconimage,iconimage,'')
        counter = 0
        for name in Regex:
            #xbmc.log('ADDING URL################################################################################### '+str(name),2)
            
            if '/mo' in name:
                name2 = 'OPENLOAD SERVER'

            if '/ok' in name:
                name2 = 'OK SERVER'

            if '/all' in name:                
                name2 = 'ESTREAM SERVER'

            if '/tb' in name:                
                name2 = 'VID2 SERVER'

            if '/or' in name:                
                name2 = 'STREAMANGO SERVER'

            if 'dailymotion.com' in name:                
                name2 = 'DAILYMOTION SERVER'

            if '/dm1' in name:
                name2 = 'Part 1'

            if '/dm2' in name:
                name2 = 'Part 2'

            if '/dm3' in name:
                name2 = 'Part 3'

            if '/dm4' in name:
                name2 = 'Part 4'

            if '/dm5' in name:
                name2 = 'Part 5'

            if '/dm6' in name:
                name2 = 'Part 6'

            if '/dm7' in name:
                name2 = 'Part 7'
            
            if '/dm' in name:
                name2 = 'DAILYMOTION SERVER'

            if '/file'in name:
                counter = counter +1
                name2 = 'Part' + str(counter)
            #def add_dir2(dir_type,mode,url,title,iconimage,fanart,description):
            if 'cn/tabs' in name:
                OPEN = Open_Url(name)
                #xbmc.log('MAIN######################################################################################## '+str(OPEN),2)
                main = re.compile('<body id=\"top\">(.+?)</html> <script type=\"text/javascript\"',re.DOTALL).findall(OPEN)
                Regex = re.compile('src="(.+?)"',re.DOTALL).findall(str(main))
                counters = 0
            	
                for tabsname in Regex:
                    counters = counters + 1
                    name = 'Part' + str(counters)
                    url  = 'https:' + tabsname
                    addDir('[B][COLOR yellow]'+name+'[/COLOR][/B]',url,40,iconimage,iconimage,'')

            else:	
                addDir('[B][COLOR yellow]'+name2+'[/COLOR][/B]',name,40,iconimage,iconimage,'')
            #add_dir('','resolve',name,,iconimage,iconimage)
            #xbmc.log('MAIN######################################################################################## '+str(name),2)
    
    
        #if 'http://libangan.ru/file'in name:
        #   xbmc.log('MAIN######################################################################################## '+str(match),2)
        #   holder = re.findall('http://libangan.ru/file/.+?', main)
        #   xbmc.log('MAIN######################################################################################## '+str(holder),2)
        #   part = 0
                #name = part
        #       for i in holder:
        #           part = part + 1
        #           name = 'Part' + str(part)
        #           add_dir('','showlink',name,'[B][COLOR yellow]'+name+'[/COLOR][/B]',icon,icon)





    #   icon = 'http:' + icon
        

        
        
        #add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart=''):
        #add_dir('','page',i[0],'[COLOR cyan]'+t+'[/COLOR]',i[1],fanart)
            


    else:
    	main = re.compile('</tbody></table><p><center>(.+?)<strong>Category</strong>',re.DOTALL).findall(OPEN)
    	#Regex = re.compile('<iframe frameborder="0".+?src="(.+?)"',re.DOTALL).findall(str(main))
        match = re.compile('(?s)<iframe.+?src="(.+?)"',re.DOTALL).findall(str(main))
        #xbmc.log('MATCH######################################################################################## '+str(main),2)

        addDir('[B][COLOR white]~~~ CHOOSE PLAYLIST BELOW & REFRESH PLAYLIST[/COLOR][/B]',url,35,iconimage,iconimage,'')
        #add_dir('','','','[B][COLOR white]~~~ CHOOSE PLAYLIST BELOW[/COLOR][/B]',iconimage,iconimage)
        counter = 0
        
        #playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        #playlist.clear()
        

        for name in match:
            counter = counter + 1
            
            name2 = 'Part' +str(counter)

            #playlist.add(name)

            if '//www.dailymotion.com/' in name:            
                name = 'http:' + name

            if '//ok.ru/' in name:
            	name = 'https:' + name

        #urlplaylist = str(playlist)


        #addDir('[B][COLOR yellow]playlist[/COLOR][/B]',urlplaylist,40,iconimage,iconimage,'')
            #orig adddir here
            addDir('[B][COLOR yellow]'+name2+'[/COLOR][/B]',name,40,iconimage,iconimage,'')
    #Regex = re.compile('<iframe frameborder="0".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    #Regex = re.compile('div id="content" role="main">(.+?)<!-- end #content -->',re.DOTALL).findall(OPEN)
    #Regex2 = re.compile('<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(str(Regex))
    
    
#LAST ALTERNATIVE
    # main2 = re.compile('LAST ALTERNATIVE VIDEO(.+?)</div> <script',re.DOTALL).findall(OPEN)
    # match2 = re.compile('(?s)<iframe.+?src="(.+?)"',re.DOTALL).findall(str(main2))
    # xbmc.log('LASTALTERNATIVENEWURL######################################################################################## '+str(main2),2)
    # #addDir('[B][COLOR white]~~~ ALTERNATIVE LINK BELOW[/COLOR][/B]',url,35,iconimage,iconimage,'')
    # #add_dir('','','','[B][COLOR white]~~~ ALTERNATIVE LINK BELOW[/COLOR][/B]',thumb,thumb)
    # counter = 0


    
        

    # for url in match2:
        
    #     counter = counter + 1

    #     if '/or' in url:
    #         name = 'STREAMANGO SERVER'
        
    #     else:
            
    #         name = 'Part' + str(counter)

    #     if '//www.dailymotion.com/' in url:
            
    #         url = 'http:' + url

    #     #playlist.addDir('[B][COLOR yellow]'+name+'[/COLOR][/B]',url,40,iconimage,iconimage,'') 
    #     #add_dir('','resolve',url,'[B][COLOR yellow]'+name+'[/COLOR][/B]',thumb,thumb)
    #     addDir('[B][COLOR yellow]'+name+'[/COLOR][/B]',url,40,iconimage,iconimage,'')

        #xbmc.log('LASTALTERNATIVENEWURL######################################################################################## '+str(url),2)

def lamb_res(url):
    #content = Read_It(url,headers)
    OPEN = Open_Url(url)
    #xbmc.log('RESOLVECONTENT####################################################################################### '+str(OPEN),2)
    if 'https://vid2-ec.dmcdn.net' in OPEN:
        #Holder = Read_It(url,headers)
        OPEN = Open_Url(url)
        url = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)[0]
        Player(url,'','')
    if 'ok.ru' in url:
        stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name,iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)


    #elif 'estream.to' in OPEN:
    #    OPEN = Open_Url(url)
    #    urltemp = re.compile('<div class=.+?container.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
    #    OPEN2 = Open_Url(urltemp)
    #    urle = re.compile("<source src=\"(.+?)\" type='application/x-mpegURL' />",re.DOTALL).findall(OPEN2)[0]
    #    Player(urle,'','')



    elif 'streamable.com' in OPEN:
        url = re.compile('"file": "(.+?)",',re.DOTALL).findall(OPEN)[0]
        #xbmc.log('STREAMABLE######################################################################################## '+str(url),2)
        Player(url,'','')
    #elif '//www.dailymotion.com' in content:
    #   url = re.findall('<iframe frameborder="0".+?src="(.+?)"',content)
    #   url = 'http:' + url
    #   stream_url = urlresolver.resolve(url)
    #elif 'streamango.com' in content
    #   Holder = Read_It(url,headers)
        

    elif 'libangan' or 'lambingan' in OPEN:
        DM = Open_Url(url)
        #xbmc.log('URL######################################################################################## '+str(url),2)
        #xbmc.log('DM######################################################################################## '+str(DM),2)
        
        if 'www.dailymotion.com' in DM:
            url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(DM)[0]
            url = 'http:' + url          
            stream_url = urlresolver.resolve(url)
        
        elif 'openload.co' in DM:
            #openload = Get_From_To(Holder,"<body id=\"top\">","</body></html>")
            openloadurl = re.findall('(?s)<a href="(.+?)"',DM)
            
            for url in openloadurl:
                url = url
            stream_url = urlresolver.resolve(url)

        elif 'estream' in DM:
            estreamurl = re.findall('(?s)<a href="(.+?)"',DM)
            for url in estreamurl:
                url = url
            stream_url = urlresolver.resolve(url)

        elif 'streamango' in DM:
            streamangourl = re.findall('(?s)<a href="(.+?)"',DM)
            for url in streamangourl:
                #xbmc.log('######################################################### '+str(url),2)

                url = url
            stream_url = urlresolver.resolve(url)


        
            
        elif 'ok.ru' in DM:
            #ok = Get_From_To(Holder,"<body id=\"top\">","</body></html>")
            okurl = re.findall('(?s)<iframe.+?src="(.+?)"',DM)
            for url in okurl:
                url = 'https:' + url
            stream_url = urlresolver.resolve(url)


        elif 'dailymotion' in DM:
            dailymotionurl = re.findall('(?s)<iframe.+?src="(.+?)"',DM)
            for url in dailymotionurl:
                url = url
            stream_url = urlresolver.resolve(url)
        
        elif 'streamablevideo' in DM:
            url = re.compile('"file": "(.+?)",.+?image:',re.DOTALL).findall(DM)[0]
           # xbmc.log('STREAMABLE######################################################################################## '+str(url),2)
            Player(url,'','')


        else:
            url = re.compile('<div class=.+?container.+?href="(.+?)"',re.DOTALL).findall(DM)[0]
        stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name,iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    
    else:
        stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name,iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    
    ###comment out below    
    #    stream_url = urlresolver.resolve(url)
    

    #else:
    #    stream_url = urlresolver.resolve(url)
    #liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    #liz.setInfo(type="Video", infoLabels={"Title": description})
    #liz.setProperty("IsPlayable","true")
    #liz.setPath(stream_url)
    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)



###################################   
def RESOLVE(url):
    #print '>>>>>>>>>>>>>>>>>>>>>>' + url + '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
    try:
        if 'speedvid.net' in url:
            OPEN = Open_Url(url)
            link = re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|',re.DOTALL).findall(OPEN)
            for port,server,hash in link:
                url = 'http://'+ server +'.speedvid.net:'+port+'/'+hash+'/v.mp4'
            stream_url=url
        elif 'watchpinoymoviesonline.info' in url:


            OPEN = Open_Url(url)
            url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        else:
            stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)") 

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

    
    
def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100 or mode==80 or mode==50 or mode==40 or mode==101 or mode==102:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

# def setView(content, viewType):
#   if content:
#       xbmcplugin.setContent(int(sys.argv[1]), content)
#   if addon.get_setting('auto-view') == 'true':
#       xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    description=urllib.unquote_plus(params["description"])
except:
    pass

if mode==None : MENU()
elif mode == 2 : pinoyonlinemenu()
#elif mode == 3 : moviechannel()
elif mode == 5 : Get_content(url) 
elif mode == 10 : Get_links(name,url)
elif mode == 20 : Mov_Menu(url)#PBA
elif mode == 24 : PinoyMov_Menu(url)
elif mode == 23 : PBALINKS(url)

elif mode == 21 : cats_mov(url)
elif mode == 22 : live_Menu(url)

###LAMBINGAN
elif mode == 30 : lamb_content(url)
elif mode == 35 : lamb_vids(name,url)
elif mode == 40 : lamb_res(url)
elif mode == 50 : RES_mov(url) 

elif mode == 60 : PHD_menu()
elif mode == 61 : PHD_ts(url)
elif mode == 62 : PHD_wdys(url)
elif mode == 63 : PHD_wends(url)
elif mode == 65 : PHD_content(url)
elif mode == 68 : PHD_links(name,url)
elif mode == 70 : PBA_content(url)
elif mode == 80 : res_live(url)
elif mode == 90 : pinoypedia_content(url)
elif mode == 91 : pinoypedia_TV(url)
elif mode == 93 : pedia_Search()
elif mode == 95 : pinoypedia_links(name,url)
elif mode == 96 : maliptv(url)
elif mode == 97 : iptv_menu(url)
elif mode ==100: RESOLVE(url)
elif mode ==101: PBA_RESOLVE(url)
elif mode ==102: resolve_IPTV(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))















