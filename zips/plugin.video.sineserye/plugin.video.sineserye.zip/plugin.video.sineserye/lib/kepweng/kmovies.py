# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests
import re, os, urllib, urllib2, sys, inspect, cookielib
#import urlresolver
import resolveurl as resolveurl
import requests, re
#from addon.common.addon import Addon
#import json
#import time

#import urlparse
#import __builtin__





def scrape_asian_movies(url):
	#xbmc.log('pass_here_scrape_asian_movies_ url ##################################################################'+str(url),2)
	
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	#
	
	mainblock = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
	#xbmc.log('scrape_movies ##################################################################'+str(mainblock),2)
	
	block1 = re.compile('href="(.+?)" class="img".+?data-original="(.+?)".+?class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(mainblock))
	sources = []
	

	for url,icon,name in block1:
		name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8216;','\'')
		source = '<name>'+name+'</name><icon>'+icon+'</icon><url>'+url+'<url>'
		sources.append(source)
	
	npblock = re.compile('<li class=\'next\'><a href=\'(.+?)\'',re.DOTALL).findall(html)

	#np = re.compile('<a href="(.+?)">Next &rsaquo;</a>' ,re.DOTALL).findall(str(npblock))
	
	for url in npblock:
		url = 'https://dramacool9.com/recently-added-movie'+url
		url = '<nextpage>nextpageonline/'+url+'</nextpage>'
		sources.append(url)

	return sources
	#xbmc.log('html ##################################################################'+str(sources),2)
	

def scrape_links(url):


	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content

	block1 = re.compile('<div class="anime_muti_link"><ul>(.+?)</ul></div>',re.DOTALL).findall(html)[0]
	#xbmc.log('scrape_links ##################################################################'+str(block1),2)
	block2 = re.compile('<li class=".+?data-video="(.+?)">.+?<span>',re.DOTALL).findall(str(block1))
	#xbmc.log('block2 ##################################################################'+str(block2),2)

	sources = []

	for url in block2:
	 	if 'https:' not in url:
	 		url = 'https:' + url
	 	if 'cloud9' in url:
	 		continue

		elif 'streaming.php?id' in url:
			#https://embed.dramacool.movie/streaming.php?id=MTkxODQ1&title=Meow%2C+the+Secret+Boy+episode+7&typesub=SUB
			
			thisRegex = r'https:\/\/embed.dramacool.movie\/streaming.php\?id=(.+?)\&title=(.+?)\&typesub'
			matches = re.compile(thisRegex,re.DOTALL).findall(url)
			for stream_id,title in matches:
				stream_id = stream_id
				title = title

			url = 'https://embed.dramacool.movie/ajax.php'

			kheaders = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',
				'refer': 'https://embed.dramacool.movie/',
				'authority': 'embed.dramacool.movie',
				'x-requested-with': 'XMLHttpRequest'}

			params = {'id': stream_id,
				'title': title,
				'typesub': 'SUB',
				'refer': 'none'}
			
			read_me = requests.get(url, params = params, headers = kheaders)
			data = read_me.content
			
			thisRegex2 = r'\[\{"file"\:"(.+?)","label":"(.+?)"'
			matches2 = re.compile(thisRegex2,re.DOTALL).findall(data)
			for link,name in matches2:
				link = link.replace('\/','/')
				name = name + ' -Server'
				
				#xbmc.log('##############################################################'+str(data),2)
				#xbmc.log('##############################################################'+str('-----'),2)
				#xbmc.log('##############################################################'+str(link),2)
				#add_dir('','dramacoolresolve2',link,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,'','')
				source = '<urlname>'+name+'</urlname><url>'+link+'</url>'
		else:
			try:
				name = url.split('//')[1].replace('www.','')
				name = name.split('/')[0].split('.')[0].title()
			except:pass           
			host = resolveurl.HostedMediaFile(url)
			ValidUrl = host.valid_url()
			if ValidUrl == True :
				#add_dir('','dramacoolresolve',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,'','')
				source = '<urlname>'+name+'</urlname><url>'+url+'</url>'
			elif ValidUrl == False:
				#"CANT BE RESOLVED"
				pass


	





		sources.append(source)

	a = str(sources)
	return a
	








	
	
#	for url in matches:

#		if 'https:' not in url:
#			url = 'https:' + url
#		xbmc.log('##############################################################'+str(url),2)
		
#		if 'cloud9' in url:
#			continue
			# cloud_id = re.compile('https://cloud9.to/embed/([a-zA-Z0-9-]+)',re.DOTALL).findall(url)
			# for cloud_link in cloud_id:
			#     cloud_api = 'https://api.cloud9.to/stream/' + cloud_link
			# xbmc.log('CLOUD ##############################################################'+str(cloud_api),2)
			
			# cheaders = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',
			#             'authority': 'api.cloud9.to',
			#             'origin': 'https://cloud9.to'}

			# read_me = requests.get(cloud_api, headers = cheaders)
			# data = read_me.content
			# xbmc.log('DATA ##############################################################'+str(data),2)
			# thisRegex2 = r'\[\{"file"\:"(.+?)"\}\]'
			# matches2 = re.compile(thisRegex2,re.DOTALL).findall(data)
			# for link in matches2:
			#     link = link.replace('\/','/')
			#     xbmc.log('DATA ##############################################################'+str(link),2)
			#     add_dir('','cloud9resolve',link,'[B][COLOR white]'+link+'[/COLOR][/B]',thumb,'','')



			

	
	#         #http://kshows.to/load.php?id=MTU2ODc0&title=Less+Than+Evil+episode+10&typesub=SUB

			


			
			

			#holder = Read_It(url,headers)
			#headers2 = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'}
			#read = requests.get(url,headers2)
			#data = read.content
			#xbmc.log('##############################################################'+str(url),2)
	#         #: 'https://hls5x.cdnfile.info/videos/hls/Cc3RoZ8bde-xrbCHUjfB_w/1548785176/156874/b48acf0d1c8d3390bf8065550d01c7fb/ep.10.m3u8',label:
			#url = re.findall('(?s)sources\:\[\{file\: \'(.+?)\',label\:',data)[0]
	#         url = matches
	#         #xbmc.log('embed.dramacool#############################################################'+str(matches),2)
	#     elif 'kshows.to/load.php' in url:
	#         holder = Read_It(url,headers)
	#         #sources:[{file: 'https://hls5x.cdnfile.info/videos/hls/Cc3RoZ8bde-xrbCHUjfB_w/1548785176/156874/b48acf0d1c8d3390bf8065550d01c7fb/ep.10.m3u8',label:
	#        matches = re.findall('(?s)sources\:\[\{file\: \'(.+?)\',label\:',holder)[0]
	#         url = matches

	#     elif 'm3u8' in url:
	#         add_dir('','dramacoolresolve',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,'','')


#origcodefromhere

	
	




	# 	else:           
	# 		host = resolveurl.HostedMediaFile(url)
	# 		ValidUrl = host.valid_url()
	# 		if ValidUrl == True :
	
	# 			sources.append(source)
		#    elif ValidUrl == False:
				#"CANT BE RESOLVED"
		#        pass
		#else:
		#	source = '<url>NO LINKS FOUND</url>'
	

	# for link in block2:
	# 	if 'https://href.li/?' in link:
	#  		link = link.replace('https://href.li/?','')
	#  	#if resolveurl.HostedMediaFile(link).valid_url():
	#  	source = '<url>'+link+'</url>'
	#  	#else:
	# 	#	source = '<url>NO LINKS FOUND</url>'
