# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests
import re, os, urllib, urllib2, sys, inspect, cookielib, time
#import urlresolver
import resolveurl as resolveurl
#from addon.common.addon import Addon
import json
import time

import urlparse
import __builtin__
import resolveurl




def scrape_movies(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	
	
	#<div class="featured-wrap clearfix">
	#thediv = dom_parser.parseDOM(html, 'div', attrs={'id':'content_box'})[0]
	#xbmc.log('PARSETESTREAD######################################################### '+str(thediv),2)
	#lists = dom_parser.parseDOM(thediv, 'li')

	mainblock = re.compile('<section class=\"container content-wrapper\">(.+?)<div class=\"pagination-wrap\">',re.DOTALL).findall(html)
	block1 = re.compile('img src="(.+?)".+?title="(.+?)">.+?<a href="(.+?)"',re.DOTALL).findall(str(mainblock))
	sources = []

	for thumb,title,link in block1:
		source = '<name>'+title+'</name><icon>'+thumb+'</icon><url>'+link+'<url>'
		#print 'Send this URL> ' + icon
		#print 'Send this URL> ' + name
		#print 'Send this URL> ' + urlGoT.append(Friends)
		sources.append(source)
	#return sources

	
	#npblock = re.compile('<div class="pagination-wrap">(.+?)<div class="clearfix">',re.DOTALL).findall(html)
	nextpage = re.compile('<a class="next page-numbers" href="(.+?)" data-wpel-link="internal">',re.DOTALL).findall(html)[0]
	xbmc.log('PARSETESTREAD######################################################### '+str(nextpage),2)
	
	#np = re.compile('class="next page-numbers" href="(.+?)"' ,re.DOTALL).findall(str(npblock))
	
	#for url in np:
	#	url = '<nextpage>nextpage/'+url+'</nextpage>'
	url = '<nextpage>nextpage/'+nextpage+'</nextpage>'

	
	sources.append(url)
	
	return sources


def scrape_episodes(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	
	
	#<div class="featured-wrap clearfix">
	#thediv = dom_parser.parseDOM(html, 'div', attrs={'id':'content_box'})[0]
	#xbmc.log('PARSETESTREAD######################################################### '+str(thediv),2)
	#lists = dom_parser.parseDOM(thediv, 'li')

	mainblock = re.compile('<section class=\"container content-wrapper\">(.+?)<div class=\"pagination-wrap\">',re.DOTALL).findall(html)
	block1 = re.compile('img src="(.+?)".+?title="(.+?)">.+?<a href="(.+?)"',re.DOTALL).findall(str(mainblock))
	sources = []

	for thumb,title,link in block1:
		source = '<name>'+title+'</name><icon>'+thumb+'</icon><url>'+link+'<url>'
		#print 'Send this URL> ' + icon
		#print 'Send this URL> ' + name
		#print 'Send this URL> ' + urlGoT.append(Friends)
		sources.append(source)
	#return sources

	
	npblock = re.compile('<div class="pagination-wrap">(.+?)<div class="clearfix">',re.DOTALL).findall(html)
	np = re.compile('class="next page-numbers" href="(.+?)"><span class="material-left">Next</span>' ,re.DOTALL).findall(str(npblock))
	
	for url in np:
		url = '<nextpage>nextpage/'+url+'</nextpage>'
		sources.append(url)
	
	return sources

def scrape_links(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content

	match = re.compile('<a class=\"dbuttn watch\" href=\"(.+?)\"',re.DOTALL).findall(html)[0]
	
	content2 = requests.get(match,headers=headers)
	content2_html = content2.content
	#xbmc.log('MATCH######################################################################## '+str(match),2)
	#xbmc.log('content2_html######################################################################## '+str(content2_html),2)

	Regex2 = re.compile('<link rel="canonical" href="(.+?)"',re.DOTALL).findall(content2_html)[0]

	#theSession = requests.Session()
	content3 = requests.get(Regex2,headers=headers)
	mkv_html = content3.content
	

	#<input type="hidden" name="_csrf_token_645a83a41868941e4692aa31e7235f2" value="30b31ff4510f697321bef2f58ae396d2cbb15ce6"/>

	theRegex = r'<input type="hidden" name="(.+?)" value="(.+?)"/>'
	Regex3 = re.compile(theRegex,re.DOTALL).findall(mkv_html)
	
	
	
	if Regex3:
	  	csrfToken = Regex3[0][0]
	  	theToken = Regex3[0][1]
	  	xbmc.log('csrfToken######################################################################## '+str(csrfToken),2)
	  	xbmc.log('theToken######################################################################## '+str(theToken),2)

	
	headers={
	 		"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36",
	 		"authority": "www.linkomark.com",
	 		"origin": "https://www.linkomark.com",
	 		"referer": Regex2,	 		
	 		}

	data = {csrfToken : theToken}
	xbmc.log('data######################################################### '+str(data),2)

	thisSource = requests.post(Regex2, data = data, headers = headers)

	thiscontent = thisSource.content
	xbmc.log('thiscontent######################################################### '+str(thiscontent),2)
	
	thisRegex2 = r'<a style=.+?href="(.+?)"'
	thisMatch = re.compile(thisRegex2,re.DOTALL).findall(str(thiscontent))

	sources = []
	for url in thisMatch:
		if  resolveurl.HostedMediaFile(url).valid_url():
			source = '<url>'+url+'</url>'
			sources.append(source)



	a = str(sources)
	return a
	
