# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests
import re, os, urllib, urllib2, sys, inspect, cookielib, base64
import resolveurl as resolveurl
#from addon.common.addon import Addon
#import json
#import random
#import time

import urlparse
#import __builtin__
import koding
import koding.router as router
from koding import route



#from lib.kepweng import kepweng_tvgo as ustvgo
from lib.kepweng import helpers as helpers
from lib.kepweng import mkv_hub as mkv
#from lib.kepweng import resolveme as resolveme
from lib.kepweng import kmovies as kmovies


from lib.airtable.airtable import Airtable
#from resource.lib.external.airtable.airtable import Airtable
	
cookiejar 		= cookielib.CookieJar()

headers 		= {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'}
addon_handle 	= int(sys.argv[1])
player 			= xbmc.Player()
dialog 			= xbmcgui.Dialog()
addon 			= xbmcaddon.Addon('plugin.video.sineserye')
addon2 			= xbmcaddon.Addon('plugin.video.PinoyReplay')
addon_name 		= addon.getAddonInfo('name')
icon 			= addon.getAddonInfo('icon')
Fanart 			= addon.getAddonInfo('fanart')
BathalaRt 		= 'https://ia601503.us.archive.org/21/items/rasonable_libero_F4/'
#https://archive.org/download/rasonable_libero_F4/
#https://ia801003.us.archive.org/8/items/rasonable_libero_F4/plbuhay.jpg
#Fanart 			= 'https://ia800707.us.archive.org/34/items/kapihannitarsilo/FanartKapihan.jpg'
#PATHth 			= 'PinoyReplay'
#addon_path 		= addon.getAddonInfo('path')
#icons 			= addon_path + "/resources/icons/"
icons 			= 'https://raw.githubusercontent.com/AkosiKepweng/fanarts/master/img/noypi/'

#main_scraper 	= 'https://ia600108.us.archive.org/21/items/source_201801/Noypi/listahan_x.txt'
#main_scraper 	= 'https://tamkepweng.000webhostapp.com/projectnoypi/listahan_x.txt'
#main_scraper2 	= 'https://ia600601.us.archive.org/29/items/aparador/aparador/listahan_x.txt'
#plugin://plugin.video.youtube/playlist/


#newsinfo 		= 'https://tamkepweng.000webhostapp.com/projectbathala/bathala_news.txt'

#pinoymovies 	= 'https://www.pinoymovieshub.com/'
xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')





		

def add_dir(dir_type='',mode='',url='',title='',iconimage='',fanart='',description=''):
	u = sys.argv[0]+"?mode="+str(mode)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	x=2; num = inspect.getargspec(add_dir); i = len(num[0])
	while i-2 >0:
		u += "&"+num[0][x]+"="+urllib.quote_plus(locals()[num[0][x]])
		x+=1; i-=1
	lis = xbmcgui.ListItem(title,iconImage=iconimage, thumbnailImage=iconimage)
	lis.setInfo( type="Video", infoLabels={"Title": title,"Plot":description})
	#liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	lis.setProperty( "Fanart_Image", fanart)


		
	if dir_type != '': fo=True
	else: fo=False ; lis.setProperty("IsPlayable","true")
	link = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=lis,isFolder=fo)
	return link





def Get_Params():
	args	= sys.argv[2]
	if len(args)<=2: return
	text = re.split('[?]',args,1)
	params1	= {}
	params = urlparse.parse_qs(text[1])
	for i in params:
		x = ''.join(params[i])
		params1.update({i:x})
	return params1


@route("Login")
def Login():
	at = Airtable('app4obSw6zHHqkJmS', 'PReplay', api_key='keylWCEKwuRI3rebp')
	match = at.get_all()	
	#xbmc.log('USERNAMESSSSSS##################'+str(match2),2)
	thisRegex = r"'user': u'(.+?)'"
	user = re.compile(thisRegex,re.DOTALL).findall(str(match))[0]
	UserName = addon2.getSetting('Email User')
	Password = addon2.getSetting('Password')
	Sagot2 = 'WeareKepweng'
		#xbmc.log('USERNAMESSSSSS##################'+str(Sagot2),2)
	if UserName == user and Password == Sagot2:
			#dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE')
		Main_Menu()
	else:
		dialog.ok('SORRY WRONG PASSWORD , PLEASE TRY AGAIN','THIS IS NOT FOR SALE','CONTACT THE ADMIN','CLICK OK TO CONTINUE CHANGE THE USERNAME PASSWORD IN THE SETTINGS')
		mode = None
		#exit()
		xbmc.executebuiltin('Dialog.Close(busydialog)')
		xbmc.executebuiltin('Activatewindow(home)')
		addon2.openSettings('plugin.video.PinoyReplay')
		


@route(mode="Menu")
def Main_Menu():
	#popup()	
	#add_dir('','','','[B][COLOR black]*[/COLOR]'+' '+'[COLOR navajowhite]CHOOSE LATEST EPISODES BELOW''[/COLOR]'+' '+'[COLOR black]''*[/COLOR][/B]',icons +'lambingan.png',Fanart)
	#add_dir('f','cinek_submenu','','[B][COLOR yellow]CINE-KEPWENG TAGALOG MOVIES[/COLOR][/B]',BathalaRt+'cinepinoy.jpg','https://ia601404.us.archive.org/32/items/bathala_walls/cinek_fnart.jpg','[B][COLOR yellow]WATCH TAGALOG MOVIES[/COLOR][/B]')
	add_dir('f','BPM_MOvies','bpm/','[B][COLOR yellow]CINE-KEPWENG TAGALOG MOVIES[/COLOR][/B]',BathalaRt+'cinepinoy.jpg','https://ia601404.us.archive.org/32/items/bathala_walls/cinek_fnart.jpg','[B][COLOR yellow]WATCH TAGALOG MOVIES[/COLOR][/B]')
	add_dir('f','tars_list_tagalogdub','','[B][COLOR peachpuff]TAGALOG DUBBED (Tarsilo\'s Direct List)[/COLOR][/B]',BathalaRt +'tarsilo_tagalog_list(1).jpg',Fanart,'[B][COLOR yellow]TAGALOG DUBBED MOVIES[/COLOR][/B]')
	#add_dir('f','bathala_web','','[B][COLOR yellow]BATHALA CABLE LIVE[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
	add_dir('f','kids_shows_main','','[B][COLOR yellow]KIDS SHOWS[/COLOR][/B]',BathalaRt +'kids_show.jpg',Fanart,'[B][COLOR yellow]KIDS MOVIES[/COLOR][/B]')
	add_dir('f','bathala_pinoy_live','','[B][COLOR peachpuff]BATHALA PINOY LIVE[/COLOR][/B]','https://ia601003.us.archive.org/8/items/rasonable_libero_F4/plbuhay.jpg',Fanart, '[B][COLOR yellow]PINOY LIVE TV[/COLOR][/B]')
	add_dir('f','asian_movies','','[B][COLOR yellow]ASIAN MOVIES[/COLOR][/B]',BathalaRt+'asian_movies.jpg',Fanart,'[B][COLOR yellow]ASIAN MOVIES[/COLOR][/B]')
	add_dir('f','korean_movies','','[B][COLOR yellow]KOREAN MOVIES[/COLOR][/B]','https://ia601003.us.archive.org/8/items/rasonable_libero_F4/IMG_20200225_101916_432.jpg',Fanart,'[B][COLOR yellow]KOREAN MOVIES[/COLOR][/B]')
	add_dir('f','MKV_Movies','teneighty/','[B][COLOR peachpuff]MKVHUB 1080p ENGLISH MOVIES[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH MOVIES[/COLOR][/B]')
	add_dir('f','MKV_Movies','seventwenty/','[B][COLOR peachpuff]MKVHUB 720p ENGLISH MOVIES[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH MOVIES[/COLOR][/B]')
	add_dir('f','MKV_Movies','palabas_asul/','[B][COLOR peachpuff]MKVHUB BLURAY ENGLISH MOVIES[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH MOVIES[/COLOR][/B]')
	#add_dir('f','SERIES9','movies/','[B][COLOR yellow]SERIES9 ENGLISH MOVIES[/COLOR][/B]',BathalaRt+'series.jpg',Fanart, '[B][COLOR yellow]ENGLISH MOVIES[/COLOR][/B]')
	
	#add_dir('f','Movies_SubMenu','','[B][COLOR yellow]ENGLISH MOVIES (WEB SOURCE)[/COLOR][/B]',BathalaRt+'english_movies.jpg',Fanart,'[B][COLOR yellow]ENGLISH MOVIES[/COLOR][/B]')
	
	

	
	#add_dir('f','scrape_tvmovie_pages','oltd/','[B][COLOR yellow]TAGALOG DUBBED (WEB SOURCE)[/COLOR][/B]',BathalaRt +'tagalog_dubbed.jpg',Fanart,'[B][COLOR yellow]WATCH TAGALOG DUBBED MOVIES[/COLOR][/B]')
	
	#add_dir('f','Bathala_SubMenu','','[B][COLOR yellow]BATHALA LIVE[/COLOR][/B]',BathalaRt+'cinepinoy.jpg','https://ia601404.us.archive.org/32/items/bathala_walls/cinek_fnart.jpg','[B][COLOR yellow]WATCH TAGALOG MOVIES[/COLOR][/B]')

	add_dir('f','tars_list','','[B][COLOR peachpuff]TARSILO\'S MOVIE CHOICE[/COLOR][/B]',BathalaRt+'tarsilo_choice.jpg',Fanart,'[B][COLOR yellow]TARSILO MOVIE CHOICE[/COLOR][/B]')
	add_dir('f','mayk_list','','[B][COLOR yellow]MAYK\'S BLOCKBUSTER MOVIES[/COLOR][/B]','https://ia601003.us.archive.org/8/items/rasonable_libero_F4/IMG_20200225_102908_235.jpg',Fanart,'[B][COLOR yellow]MAYKS MOVIE CHOICE[/COLOR][/B]')
	add_dir('f','mayk_boxset','','[B][COLOR yellow]MAYK\'S MOVIE BOX SET (English Movies)[/COLOR][/B]',BathalaRt+'mayks_collection.jpg',Fanart,'[B][COLOR yellow][/COLOR][/B]')
	
	#add_dir('f','TM_EnglishMOvies','','[B][COLOR yellow]D\'TARSILO\'S CHOICE (English Movies)[/COLOR][/B]',BathalaRt+'tarsilo_choice.jpg',Fanart,'[B][COLOR yellow][/COLOR][/B]')
	#add_dir('f','batman','maykschoice/','[B][COLOR yellow]MAYK\'S CHOICE (English Movies)[/COLOR][/B]',BathalaRt+'tarsilo_choice.jpg',Fanart,'[B][COLOR yellow][/COLOR][/B]')
	#add_dir('f','series9','tvseries','[B][COLOR yellow]SERIES9 TV NEW EPISODES[/COLOR][/B]',BathalaRt+'new_episodes_series9.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
	
	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

	
#@route(mode="Bathala_Scraper")
#def Bathala_Scraper():
#@route(mode="cinek_submenu")
#def cinek_submenu():
#	add_dir('f','BPM_MOvies','bpm/','[B][COLOR yellow]LATEST PINOY MOVIES (DIRECT LINKS)[/COLOR][/B]',BathalaRt+'pmo.jpg',Fanart,)
#	add_dir('f','scrape_tvmovie_pages','sinepinoy/','[B][COLOR yellow]LATEST PINOY MOVIES (WEBSOURCE)[/COLOR][/B]',BathalaRt+'pmo.jpg',Fanart,)
#	add_dir('f','scrape_tvmovie_pages','sinepinoyclassic/','[B][COLOR yellow]PINOY CLASSIC MOVIES ONLINE[/COLOR][/B]',BathalaRt+'pinoy_classic.jpg',Fanart,)
	#add_dir('f','scrape_tvmovie_pages','pmp/','[B][COLOR yellow]PINOY MOVIEPEDIA[/COLOR][/B]',BathalaRt+'pmp.jpg',Fanart,)
	#add_dir('f','scrape_tvmovie_pages','pmoc/','[B][COLOR yellow]PINOY CLASSIC MOVIES ONLINE[/COLOR][/B]','https://ia801404.us.archive.org/32/items/bathala_walls/series9.png',Fanart,)
		#add_dir('f','mkvhub_tvseries','mkvtvshows/','[B][COLOR hotpink]MKVHUB TV SERIES[/COLOR][/B]','https://ia801404.us.archive.org/32/items/bathala_walls/series9.png',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
#	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
	
	
#add_dir('f','new_episodes','popularshows/','[B][COLOR yellow]KEPWENG-TV POPULAR SHOWS[/COLOR][/B]','https://ia801404.us.archive.org/32/items/bathala_walls/newepisode.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
#@route(mode="kids_shows_main")
#def kids_shows_main():
#	add_dir('f','kids_shows_sub','','[B][COLOR yellow]BEYBLADE[/COLOR][/B]','https://image.tmdb.org/t/p/original/cyCVSVtrc5KQGkrNIZf5wLrzEgd.jpg','https://image.tmdb.org/t/p/original/osP62fWwRLgp1LtVjipW4NetQQ2.jpg')
#	add_dir('f','TM_MOvies','pixars/','[B][COLOR yellow]PIXARS MOVIES[/COLOR][/B]','','')

@route(mode="kids_shows_main")
def kids_shows_sub():
	add_dir('f','pixar_list','','[B][COLOR yellow]PIXAR[/COLOR][/B]','https://image.tmdb.org/t/p/original/4Nig8sG9MZnPvbKItlh8tGXCdls.jpg','https://image.tmdb.org/t/p/original/4Nig8sG9MZnPvbKItlh8tGXCdls.jpg')
	#add_dir('f','TM_MOvies','beyblad/','[B][COLOR yellow]Beyblade (2001)[/COLOR][/B]','https://image.tmdb.org/t/p/original/cyCVSVtrc5KQGkrNIZf5wLrzEgd.jpg','https://image.tmdb.org/t/p/original/osP62fWwRLgp1LtVjipW4NetQQ2.jpg')
#	add_dir('f','TM_MOvies','vforce/','[B][COLOR yellow]Beyblade V-FORCE (2002)[/COLOR][/B]','https://image.tmdb.org/t/p/original/cyCVSVtrc5KQGkrNIZf5wLrzEgd.jpg','https://image.tmdb.org/t/p/original/osP62fWwRLgp1LtVjipW4NetQQ2.jpg')
#	add_dir('f','TM_MOvies','grevolution/','[B][COLOR yellow]Beyblade G-Revolution (2003)[/COLOR][/B]','https://image.tmdb.org/t/p/original/cyCVSVtrc5KQGkrNIZf5wLrzEgd.jpg','https://image.tmdb.org/t/p/original/osP62fWwRLgp1LtVjipW4NetQQ2.jpg')

#	add_dir('f','TM_MOvies','beyblademetal/','[B][COLOR yellow]Beyblade: Metal Fusion (2009)[/COLOR][/B]','https://image.tmdb.org/t/p/original/aQ5LhK7FcgivVrHZn6Kvwy0HpCY.jpg','https://image.tmdb.org/t/p/original/pLgHhpPnfeujAQR6Vj9PbOrCwhm.jpg')
#	add_dir('f','TM_MOvies','beybladeburst/','[B][COLOR yellow]Beyblade: Burst (2016)[/COLOR][/B]','https://image.tmdb.org/t/p/original/fG7BHxDlntPyB57UuNo9sXmAmLV.jpg','https://image.tmdb.org/t/p/original/bpbWrKlBRxtp1iCxtHDC5Y1eMEs.jpg')
#	add_dir('f','TM_MOvies','beybladeevo/','[B][COLOR yellow]Beyblade: Burst Evolution (2016)[/COLOR][/B]','https://image.tmdb.org/t/p/original/fG7BHxDlntPyB57UuNo9sXmAmLV.jpg','https://image.tmdb.org/t/p/original/bpbWrKlBRxtp1iCxtHDC5Y1eMEs.jpg')
	





	
#@route(mode="Bathala_SubMenu")
#def Bathala_SubMenu():
#	#orig mode 'bathala_live'
#	add_dir('f','bathala_live','','[B][COLOR yellow]BATHALA IPTV[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
#	#orig mode 'bathala_web'
#	add_dir('f','bathala_web','','[B][COLOR yellow]BATHALA LIVE WEBTV -(MULTI-USER)[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')

# @route(mode="Bathala_joke")
# def Bathala_joke():
# 	dialog = xbmcgui.Dialog()
# 	ok = dialog.ok('Notice', 'Device your using is not compatible. For Shield Users only.')


#@route(mode="bathala_web")
#def Bathala_Web():
#	add_dir('f','bathala_web_scrape','https://ustvgo.tv/category/entertainment/','[B][COLOR yellow]ENTERTAINMENT CHANNEL[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
#	#add_dir('f','bathala_web_scrape','','[B][COLOR yellow]NEWS CHANNEL[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
#	add_dir('f','bathala_web_scrape','https://ustvgo.tv/category/sports/','[B][COLOR yellow]SPORTS CHANNEL[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
#	add_dir('f','bathala_web_scrape','https://ustvgo.tv/category/kids/','[B][COLOR yellow]KIDS CHANNEL[/COLOR][/B]',BathalaRt+'mkvhub.jpg',Fanart, '[B][COLOR yellow]ENGLISH TV SERIES NEW EPISODES[/COLOR][/B]')
	
	


#@route(mode='submenu2')
#def Sub_Menu2():
	#xbmc.executebuiltin('XBMC.RunAddon(plugin.video.youtube)')
#	xbmc.executebuiltin('XBMC.RunAddon("plugin.video.dailymotion_com/?url=k16tjC2ZZHNrwBt5uu6&mode=playVideo")')
	#xbmc.executebuiltin('XBMC.RunPlugin("plugin.video.dailymotion_com")')
	#xbmc.RunPlugin('plugin://plugin.video.dailymotion_com/?url=k16tjC2ZZHNrwBt5uu6&mode=playVideo')
	#xbmc.executebuiltin("ActivateWindow(10025,'plugin.video.dailymotion_com/',return)")
	#xbmc.executebuiltin('RunPlugin(plugin://plugin.video.dailymotion_com/?url=k16tjC2ZZHNrwBt5uu6&mode=playVideo)')
	#xbmc.executebuiltin('XBMC.RunAddon( plugin://plugin.video.dailymotion_com)')


def popup():
	#message=Open_Url(newsinfo)
	message = requests.get('https://pastebin.com/raw/fPEHKpxs',headers = headers)
	PasteBin_PopupNews = message.content
	#xbmc.log('NP##################'+str(message),2)
	if len(PasteBin_PopupNews)>1:
		path = xbmcaddon.Addon().getAddonInfo('path')
		comparefile = os.path.join(os.path.join(path,''), 'bathala_news.txt')
		r = open(comparefile)
		compfile = r.read()
		#xbmc.log('COMFILE##################'+str(compfile),2)       
		if compfile == PasteBin_PopupNews:pass
		else:
			showText('[B][COLOR gold]IMPORTANT NEWS[/COLOR][/B]', PasteBin_PopupNews)
			text_file = open(comparefile, "w")
			text_file.write(PasteBin_PopupNews)
			text_file.close()

def showText(heading, text):
	id = 10147
	xbmc.executebuiltin('ActivateWindow(%d)' % id)
	xbmc.sleep(500)
	win = xbmcgui.Window(id)
	retry = 50
	while (retry > 0):
		try:
			xbmc.sleep(10)
			retry -= 1
			win.getControl(1).setLabel(heading)
			win.getControl(5).setText(text)
			quit()
			return
		except: pass


#START CODE HERE
@route(mode='BPM_MOvies')
def BPM_MOvies():
	if 'bpm/' in url:
		at = Airtable('appHxI28sQjXfvf9p', 'Pinoy Movies', api_key='keyE0ZoOUBV94U2Os')
		match = at.get_all(maxRecords=700, sort=['-id number'])
		match2 = str(match)
		#xbmc.log('match##################################################################'+str(match),2)
		#{u'Name': u'', u'fanart': u'', u'id number':, u'summary': u'', u'url5': u'', u'url4': u'', u'url1': u'', u'url3': u'', u'url2': u'', u'icon': u''
		thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'id number':.+?, u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
		Regex_me = re.compile(thisRegex2,re.DOTALL).findall(match2)
		for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:
			if 'no-url' in url1:
				continue
			#if url2 == '-':
			#	continue		
			playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
			add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)
		
		add_dir('f','BPM_MOvies','Pinoy_Movies2/','[B][COLOR yellow]NEXTPAGE[/COLOR][/B]',icons+'next.png' ,fanart)

	if 'Pinoy_Movies2/' in url:
		at = Airtable('appHxI28sQjXfvf9p', 'Pinoy Movies2', api_key='keyE0ZoOUBV94U2Os')
		match = at.get_all(maxRecords=700, sort=['id number'])
		match2 = str(match)
		#xbmc.log('match##################################################################'+str(match),2)
		#{u'Name': u'', u'fanart': u'', u'id number':, u'summary': u'', u'url5': u'', u'url4': u'', u'url1': u'', u'url3': u'', u'url2': u'', u'icon': u''
		thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'id number':.+?, u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
		Regex_me = re.compile(thisRegex2,re.DOTALL).findall(match2)
		for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:
			if 'no-url' in url1:
				continue
			#if url2 == '-':
			#	continue		
			playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
			add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)
		add_dir('f','BPM_MOvies','Pinoy_Movies3/','[B][COLOR yellow]NEXTPAGE[/COLOR][/B]',icons+'next.png',fanart)

	if 'Pinoy_Movies3/' in url:
		at = Airtable('appHxI28sQjXfvf9p', 'Pinoy Movies3', api_key='keyE0ZoOUBV94U2Os')
		match = at.get_all(maxRecords=700, sort=['id number'])
		match2 = str(match)
		#xbmc.log('match##################################################################'+str(match),2)
		#{u'Name': u'', u'fanart': u'', u'id number':, u'summary': u'', u'url5': u'', u'url4': u'', u'url1': u'', u'url3': u'', u'url2': u'', u'icon': u''
		thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'id number':.+?, u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
		Regex_me = re.compile(thisRegex2,re.DOTALL).findall(match2)
		for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:
			if 'no-url' in url1:
				continue
			#if url2 == '-':
			#	continue		
			playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
			add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)
		add_dir('f','BPM_MOvies','Pinoy_Movies4/','[B][COLOR yellow]NEXTPAGE[/COLOR][/B]',icons+'next.png',fanart)

	if 'Pinoy_Movies4/' in url:
		at = Airtable('appHxI28sQjXfvf9p', 'Pinoy Movies4', api_key='keyE0ZoOUBV94U2Os')
		match = at.get_all(maxRecords=700, sort=['id number'])
		match2 = str(match)
		#xbmc.log('match##################################################################'+str(match),2)
		#{u'Name': u'', u'fanart': u'', u'id number':, u'summary': u'', u'url5': u'', u'url4': u'', u'url1': u'', u'url3': u'', u'url2': u'', u'icon': u''
		thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'id number':.+?, u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
		Regex_me = re.compile(thisRegex2,re.DOTALL).findall(match2)
		for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:
			if 'no-url' in url1:
				continue
			#if url2 == '-':
			#	continue		
			playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
			add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)
		#add_dir('f','BPM_MOvies','Pinoy_Movies5/','[B][COLOR yellow]NEXTPAGE[/COLOR][/B]',icon,fanart)


#TAGALOG DUBBED
@route(mode='tars_list_tagalogdub')
def tars_list_tagalogdub():
	#PASTEBIN CATEGORY SUMMARY
	headers_pastebin = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Read_Category_Tars_Choice = requests.get('https://pastebin.com/raw/87zVVRhm', headers=headers_pastebin)
	TarsList = Read_Category_Tars_Choice.text
	

	tars_block = re.compile('<tarsilo3>(.+?)</tarsilo3>',re.DOTALL).findall(TarsList)[0]
	#xbmc.log('mayks_block##################################################################'+str(mayks_block),2)
	tars_id = re.compile('<table>(.+?)</table>',re.DOTALL).findall(str(tars_block))[0]
	#xbmc.log('tars_id##################################################################'+str(tars_id),2)
	'''
	<tarsilo2>
		<name>TARSILO'S CHOICE</name><table>Tribunians</table>
	</tarsilo2>
	'''
	at = Airtable('appIxO2SaYmo3xlPJ',tars_id, api_key='keyE0ZoOUBV94U2Os')#orig table
	match = at.get_all(sort=['-id number'])
	#xbmc.log('match##################################################################'+str(match),2)

	thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'id number':.+?, u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
	Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(match))
	for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:		
		playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
		
		add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)


#bathala_pinoy_live
@route(mode='bathala_pinoy_live')
def bathala_pinoy_live():
	#PASTEBIN CATEGORY SUMMARY
	#headers_pastebin = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	#Read_Category_Tars_Choice = requests.get('https://pastebin.com/raw/87zVVRhm', headers=headers_pastebin)
	#TarsList = Read_Category_Tars_Choice.text	

	#tars_block = re.compile('<tarsilo2>(.+?)</tarsilo2>',re.DOTALL).findall(TarsList)[0]	
	#tars_id = re.compile('<table>(.+?)</table>',re.DOTALL).findall(str(tars_block))[0]
	
	at = Airtable('app3zsYHDvac3No3S','Bathala_Pinoy_Channels', api_key='keyE0ZoOUBV94U2Os')#orig table
	match = at.get_all(sort=['Name'])
	#xbmc.log('match##################################################################'+str(match),2)


	thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'id number':.+?, u'url10': u'(.+?)', u'summary': u'(.+?)', u'url5': u'(.+?)', u'url4': u'(.+?)', u'url7': u'(.+?)', u'url6': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'url9': u'(.+?)', u'url8': u'(.+?)', u'icon': u'(.+?)'"
	Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(match))
	for name,fanart,url10,summary,url5,url4,url7,url6,url1,url3,url2,url9,url8,icon in Regex_me:
		
		playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url><url>'+url6+'</url><url>'+url7+'</url><url>'+url8+'</url><url>'+url9+'</url><url>'+url10+'</url>'
		add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)


#ASIAN MOVIES HERE
@route(mode='asian_movies', args=["url"])
def asian_movies(url):

	if 'nextpageonline/' in url:
		url = url.replace('nextpageonline/', '')
		#nextpage>nextpageonline/https://dramacool9.com/recently-added-movie?page=2</nextpage>
		url = url
		#xbmc.log('nextpageonline url ##################################################################'+str(url),2)
		scrape = kmovies.scrape_asian_movies(url)	
		thisRegex2 = r'<name>(.+?)</name><icon>(.+?)</icon><url>(.+?)<url>'
		Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(scrape))	
		for name,icon,url in Regex_me:
		#	xbmc.log('MKVNAME##################################################################'+str(name),2)
			name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&').replace('\\\\xe2\\\\x80\\\\x99','\'')
			add_dir('f','get_asian_movies_link',url,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,icon,name)

		thisRegex3 = r'<nextpage>(.+?)</nextpage>'
		np = re.compile(thisRegex3,re.DOTALL).findall(str(scrape))
		for url in np:
			#xbmc.log('ASIAN MOVIE ##################################################################'+str(url),2)
			add_dir('f','asian_movies',url,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')

	else:
		url = 'https://dramacool9.com/recently-added-movie'
		#xbmc.log('ASIANMOVIES##################################################################'+str(url),2)
		scrape = kmovies.scrape_asian_movies(url)
		#xbmc.log('SCRAPE##################################################################'+str(scrape),2)
		
		thisRegex2 = r'<name>(.+?)</name><icon>(.+?)</icon><url>(.+?)<url>'
		Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(scrape))	
		for name,icon,url in Regex_me:
		#	xbmc.log('MKVNAME##################################################################'+str(name),2)
			name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&').replace('\\\\xe2\\\\x80\\\\x99','\'')
			add_dir('f','get_asian_movies_link',url,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,icon,name)

		thisRegex3 = r'<nextpage>(.+?)</nextpage>'
		np = re.compile(thisRegex3,re.DOTALL).findall(str(scrape))[0]
		#xbmc.log('NEXT URL##################################################################'+str(np),2)
		add_dir('f','asian_movies',np,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')
		
		#for url in np:
			#xbmc.log('NEXT URL##################################################################'+str(np),2)
		#	add_dir('f','asian_movies',url,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')



#'KOREA MOVIES
@route(mode='korean_movies', args=["url"])
def korean_movies(url):
	url = 'https://dramacool9.com/category/korean-movies'
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	
	#xbmc.log('URL##################################################################'+str(url),2)
	add_dir('','','','[B][COLOR white]-= CHOOSE MOVIE YEAR BELOW =-[/COLOR][/B]','','','')
	mainblock = re.compile('<select id="select-year">.+?<option value="">-Select Year-</option>(.+?)</select>',re.DOTALL).findall(html)
	block1 = re.compile('<option value="(.+?)">(.+?)</option>',re.DOTALL).findall(str(mainblock))
	
	for year_url,year_title in block1:
		url = year_url+'/'
	#	xbmc.log('year_url##################################################################'+str(year_url),2)
	#	xbmc.log('year_title##################################################################'+str(year_title),2)
	
		add_dir('f','get_year',url,'[B][COLOR white]'+year_title+'[/COLOR][/B]','','','')
		#add_dir('f','get_series9_links',url,'[B][COLOR yellow]'+name+' - '+quality+'[/COLOR][/B]',icon,icon,name)

@route(mode='get_year', args=["url"])
def get_year(url):
	if '/' in url:
		url = url.replace('/', '')

	main_url = 'https://dramacool9.com/category/korean-movies'
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	
	Readit = requests.get(main_url,headers=headers)
	html = Readit.content


	#xbmc.log('url##################################################################'+str(html),2)
	regexme = r'<span class="year">'+url+'</span>.+?<a href="(.+?)" title="(.+?)">'
	#xbmc.log('regexme##################################################################'+str(regexme),2)
	block1 = re.compile(regexme,re.DOTALL).findall(html)


	pd = xbmcgui.DialogProgress()
	pd.create('Please Wait ...Dont Cancel')


	m = len(regexme)
	per = 100/m
	c=0
	num = 1






	for temp_url,title in block1:
		
		url = 'https://dramacool9.com'+temp_url

		pd.update(int(c*per),line1='[B][COLOR yellow]Adding & Checking Title[/COLOR][/B]', line2='[B][COLOR white]{}[/COLOR][/B]'.format(title))
		
		temp_readit = requests.get(url,headers=headers)
		html_temp = temp_readit.content

		regexme2 = r'<div class="content-left">.+?<div class="img">.+?<img src="(.+?)"'
		regex_desc = r'<span>Description:</span>.+?<p>(.+?)</p>'
		regex_link = r'<div class="block tab-container">.+?<a href="(.+?)"'
		regex_sub = r'<div class="block tab-container">.+?<span class="type.+?>(.+?)</span>'
		
		block2 = re.compile(regexme2,re.DOTALL).findall(html_temp)
		block_desc = re.compile(regex_desc,re.DOTALL).findall(html_temp)
		block_link = re.compile(regex_link,re.DOTALL).findall(html_temp)
		block_sub = re.compile(regex_sub,re.DOTALL).findall(html_temp)
		#xbmc.log('url##################################################################'+str(url),2)
		

		for img in block2:
			img = img
		for desc in block_desc:
			desc = desc
		for link in block_link:
			link = link
		for sub in block_sub:
			sub = sub
		title = title+' ('+sub+')'
		#xbmc.log('html_temp##################################################################'+str(title),2)


		add_dir('f','get_asian_movies_link',link,'[B][COLOR yellow]'+title+'[/COLOR][/B]',img,img,desc)

		c += 1
		num += 1
	pd.close()

#MKVHUB CODE HERE
@route(mode='MKV_Movies', args=["url"])
def mkvhub_movies(url):
	if 'nextpage/' in url:
		url = url.replace('nextpage/', '')

	elif 'teneighty/' in url:
		url = url.replace('teneighty/', '')
		url = 'https://www.mkvhub.com/category/1080p-movies/'

	elif 'seventwenty/' in url:
		url = url.replace('seventwenty/', '')
		url = 'https://www.mkvhub.net/category/720p-movies/'
	elif 'palabas_asul/' in url:
		url = url.replace('palabas_asul/', '')
		url = 'https://www.mkvhub.net/category/bluray-movies-collection/'

	scrape = mkv.scrape_movies(url)
	#xbmc.log('scrape_tvmovie_pages ##################################################################'+str(scrape),2)
	thisRegex2 = r'<name>(.+?)</name><icon>(.+?)</icon><url>(.+?)<url>'
	Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(scrape))	
	for name,icon,url in Regex_me:
	#	xbmc.log('MKVNAME##################################################################'+str(name),2)
		name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&').replace('\\\\xe2\\\\x80\\\\x99','\'')
		add_dir('f','mkvhub_getlinks2',url,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,icon,name)

	
	thisRegex3 = r'<nextpage>(.+?)</nextpage>'
	np = re.compile(thisRegex3,re.DOTALL).findall(str(scrape))
	#xbmc.log('NPscrape##################################################################'+str(np),2)
	for url in np:
		add_dir('f','MKV_Movies',url,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')
	#xbmc.executebuiltin('Container.SetViewMode(500)')
	xbmc.executebuiltin('Container.SetViewMode(512)')

#SERIES9_CODE_HERE
@route(mode='SERIES9', args=["url"])
def series9_movies(url):
	
	if 'nextpage/' in url:
		url = url.replace('nextpage/', '')    
		url = url
		#xbmc.log('2nd URL######################################################### '+str(url),2)

	#elif 'getshowlist/' in url:
	#	url = url.replace('getshowlist/', '')    
	#	url = url
	#tvseries
	#elif 'tvseries' in url:
	#	url = url.replace('tvseries', '')
	#	url = 'https://www1.series9.to/movie/filter/series-featured/all/all/all/all/latest/'    
	
	elif 'movies' in url:
		url = url.replace('movies', '')
		#url = 'https://www2.seriesonline8.co/movie/filter/series-featured/all/all/all/all/latest/'
		url = 'https://series9.to/movie/filter/movie/all/all/all/all/latest/'
	
	#else:
	#	url = "https://www2.series9.io/movie/filter/series/all/all/all/all/latest/"

	#xbmc.log('PINOYREWIND######################################################### '+str(url),2)

	#url = 'http://www.lambingan.su/blog/'
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	#xbmc.log('PINOYREWIND######################################################### '+str(html),2)

	block1 = re.compile('<div class="movies-list movies-list-full">(.+?)<div id="pagination">',re.DOTALL).findall(html)[0]
	match = re.findall('(?s)<div class="ml-item">.+?<a href="(.+?)".+?<span class.+?>(.+?)</span>.+?<img data-original="(.+?)".+?<span class="mli-info"><h2>(.+?)</h2>',block1)
	#match = re.findall('(?s)<h2 class=\'post-title entry-title\'>\n<a href=\'(.+?)\'>(.+?)</a>.+?<script type=\'text/javascript\'>.+?creator\("(.+?)"',block1)
	#xbmc.log('BLOCK!MATCHPINOYREWINDICON################################################################## '+str(block1),2)
	#('http://www.pinoyrewind.info/2019/02/tonight-with-boy-abunda-february-26-2019.html', 'https://4.bp.blogspot.com/-53HH_Du83zM/Vgl3DCnayNI/AAAAAAAAALI/SoqOArpSw1U/s72-c/TWBA.jpg', 'Tonight with Boy Abunda ', ' February 26, 2019')
		
	for url,quality,icon,name in match:
		#xbmc.log('NAME_MATCH################################################################## '+str(name),2)
		name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
		quality = quality.replace('<i>','').replace('</i>','')
		if 'http' not in icon:
			icon = 'https:' + icon
		
		add_dir('f','get_series9_links',url,'[B][COLOR yellow]'+name+' - '+quality+'[/COLOR][/B]',icon,icon,name)
	xbmc.executebuiltin('Container.SetViewMode(500)')	
		
	
	if '<div id="pagination">' in html:
		npblock = re.compile('<div id="pagination">(.+?)<div id="footer">',re.DOTALL).findall(html)
		#<li  class=active><a href='?page=3' data-page='3'>3</a></li><li ><a href='?page=4' data-page=
		np = re.compile('<li  class=active>.+?</a></li><li ><a href=\'(.+?)\'' ,re.DOTALL).findall(str(npblock))
		
		for url in np:
			url = 'https://series9.to/movie/filter/movie/all/all/all/all/latest/' + url

		
		add_dir('f','series9','nextpage/'+ url,'[B][COLOR red]Next Page [/COLOR][COLOR white] to go back use top kodi link [/COLOR][/B]',icons + 'next.png',Fanart)
	xbmc.executebuiltin('Container.SetViewMode(500)')



#PIXAR LIST
@route(mode='pixar_list')
def pixar_list():
	#PASTEBIN CATEGORY SUMMARY
	headers_pastebin = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	#Read_Category_Tars_Choice = requests.get('https://pastebin.com/raw/87zVVRhm', headers=headers_pastebin)
	#TarsList = Read_Category_Tars_Choice.text
	

	#tars_block = re.compile('<tarsilo2>(.+?)</tarsilo2>',re.DOTALL).findall(TarsList)[0]
	#xbmc.log('mayks_block##################################################################'+str(mayks_block),2)
	#tars_id = re.compile('<table>(.+?)</table>',re.DOTALL).findall(str(tars_block))[0]
	#xbmc.log('tars_id##################################################################'+str(tars_id),2)
	'''
	<tarsilo2>
		<name>TARSILO'S CHOICE</name><table>Tribunians</table>
	</tarsilo2>
	'''
	at = Airtable('app4obSw6zHHqkJmS','pixar', api_key='keylWCEKwuRI3rebp')#orig table
	match = at.get_all(sort=['-Sort No.'])
	#xbmc.log('match##################################################################'+str(match),2)
	#u'url5': u' - ', u'url4': u' - ', u'url1': u' - ', u'url3': u' - ', u'url2': u' - ', u'icon': u'https://image.tmdb.org/t/p/w500//nk11pvocdb5zbFhX5oq5YiLPYMo.jpg'}, u'id': u'rec09YfkYbtPXkGFF'}

	thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)',.+?u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
	Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(match))
	for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:
		playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
		add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)

#TARSILO LIST
@route(mode='tars_list')
def tars_list():
	#PASTEBIN CATEGORY SUMMARY
	headers_pastebin = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Read_Category_Tars_Choice = requests.get('https://pastebin.com/raw/87zVVRhm', headers=headers_pastebin)
	TarsList = Read_Category_Tars_Choice.text
	

	tars_block = re.compile('<tarsilo2>(.+?)</tarsilo2>',re.DOTALL).findall(TarsList)[0]
	#xbmc.log('mayks_block##################################################################'+str(mayks_block),2)
	tars_id = re.compile('<table>(.+?)</table>',re.DOTALL).findall(str(tars_block))[0]
	#xbmc.log('tars_id##################################################################'+str(tars_id),2)
	'''
	<tarsilo2>
		<name>TARSILO'S CHOICE</name><table>Tribunians</table>
	</tarsilo2>
	'''
	at = Airtable('appIxO2SaYmo3xlPJ',tars_id, api_key='keyE0ZoOUBV94U2Os')#orig table
	match = at.get_all(sort=['-id number'])
	#xbmc.log('match##################################################################'+str(match),2)

	thisRegex2 = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'id number':.+?, u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
	Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(match))
	for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:		
		playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
		
		add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)
	

	#for name,table_id in tars:
	#	add_dir('f','TarsiloList',table_id,'[B][COLOR yellow]'+name+'[/COLOR][/B]','','','[B][COLOR yellow]WATCH MOVIES[/COLOR][/B]')







#MAYKS LIST
@route(mode='mayk_list')
def mayk_list():
	#PASTEBIN CATEGORY SUMMARY
	# headers_pastebin = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	# Read_Category_Mayks_Choice = requests.get('https://pastebin.com/raw/Z2AG8j1x', headers=headers_pastebin)
	# MayksList = Read_Category_Mayks_Choice.text
	# #xbmc.log('mayks_block##################################################################'+str(MayksList),2)
	

	# mayks_block = re.compile('<mayks_choice>(.+?)</mayks_choice>',re.DOTALL).findall(MayksList)[0]
	# xbmc.log('mayks_block##################################################################'+str(mayks_block),2)
	#mayks_id = re.compile('<table>(.+?)</table>',re.DOTALL).findall(str(mayks_block))[0]
	#xbmc.log('tars_id##################################################################'+str(mayks_id),2)
	'''
	<tarsilo2>
		<name>TARSILO'S CHOICE</name><table>Tribunians</table>
	</tarsilo2>
	'''
	at = Airtable('appkvviMX827pjFGZ', 'Mayks_Choice', api_key='key8QbpBTgarpcxBa')#orig table
	#match = at.get_all(maxRecords=700, sort=['-sort no.'])
	match = at.get_all(sort=['-sort no.'])
	#xbmc.log('match##################################################################'+str(match),2)

	#{u'Name': u'Lion King (2019)', u'fanart': u'https://image.tmdb.org/t/p/original/otQ5Lc62duziFVbv3fAyEXKXtCO.jpg', u'url5': u'no-url', u'url4': u'no-url', u'url1': u'https://jplayer.net/v/rgdx2tepx8zl65l', u'sort no.': 2, u'url3': u'no-url', u'url2': u'no-url', u'icon': u'https://image.tmdb.org/t/p/original/2bXbqYdUdNVa8VIWXVfclP2ICtT.jpg'}
	thisRegex = r"u'Name': u'(.+?)', u'fanart': u'(.+?)', u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'sort no.':.+?, u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
	Regex_me = re.compile(thisRegex,re.DOTALL).findall(str(match))
	for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:		
	 	playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
	 	add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)
	

	#for name,table_id in tars:
	#	add_dir('f','TarsiloList',table_id,'[B][COLOR yellow]'+name+'[/COLOR][/B]','','','[B][COLOR yellow]WATCH MOVIES[/COLOR][/B]')


@route(mode='mayk_boxset')
def mayk_boxset():
	#PASTEBIN CATEGORY SUMMARY
	headers_pastebin = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Read_Category_Mayks_BoxSet = requests.get('https://pastebin.com/raw/Z2AG8j1x', headers=headers_pastebin)
	Mayks_BoxSet = Read_Category_Mayks_BoxSet.text
	
	mayks_block = re.compile('<mayks_boxset>(.+?)</mayks_boxset>',re.DOTALL).findall(Mayks_BoxSet)[0]
	box_set = re.compile('<name>(.+?)</name><table>(.+?)</table><poster>(.+?)</poster>',re.DOTALL).findall(str(mayks_block))
	
	for name,table_id,poster in box_set:
		add_dir('f','boxset_data',table_id,'[B][COLOR yellow]'+name+'[/COLOR][/B]',poster,poster,'[B][COLOR yellow]WATCH BOX SET MOVIES[/COLOR][/B]')

@route(mode='boxset_data', args=["url"])
def boxset_data(url):
	#xbmc.log('match##################################################################'+str(url),2)
	at = Airtable('appMOg2Tlk4jW5zRK', url, api_key='key8QbpBTgarpcxBa')#orig table
	match = at.get_all(sort=['-id number'])
	#xbmc.log('match##################################################################'+str(match),2)
	#, u'id number': 3, u'summary': u', u'url5': u'no-url', u'url4': u'no-url', u'url1': u'https://votrefiles.club/v/0e1jqfldyww5ln8', u'url3': u'https://mstream.xyz/97e2xp47gxn0', u'url2': u'https://gcloud.live/v/-w6debpme31z7-m', u'icon': u'https://image.tmdb.org/t/p/original/ynMQ4nVwkoP2gLxXXDgcdltihTD.jpg'}
	thisRegex = r"u'Name': u'(.+?)', u'fanart': u'(.+?)',.+?u'summary': u(.+?), u'url5': u'(.+?)', u'url4': u'(.+?)', u'url1': u'(.+?)', u'url3': u'(.+?)', u'url2': u'(.+?)', u'icon': u'(.+?)'"
	Regex_me = re.compile(thisRegex,re.DOTALL).findall(str(match))
	for name,fanart,summary,url5,url4,url1,url3,url2,icon in Regex_me:
		playlist = '<url>'+url1+'</url><url>'+url2+'</url><url>'+url3+'</url><url>'+url4+'</url><url>'+url5+'</url>'
	 	add_dir('f','TM_links',playlist,'[B][COLOR white]'+name+'[/COLOR][/B]',icon,fanart,summary)
	


# def gen_ip():
#     ip1 = '3.128.0.0'
#     ip2 = '3.247.255.255'

#     newIP = []

#     newip = ''

#     for x, y in zip(ip1.split('.'), ip2.split('.')):
     
#         if x == y: newIP.append (int(x)) 
        
#         else : newIP.append (random.randint(int(x), int(y) + 1)) 
            
#     newip = str(newIP[0]) + '.' + str(newIP[1]) + '.' + str(newIP[2]) + '.' + str(newIP[3])
    

#     #print '' 

#     #print newip
#     return newip



#@route(mode='bathala_web_scrape', args=["url"])
#def bathala_web_scrape(url):
	
	
	#xbmc.log('URL ##################################################################'+str(url),2)
	#IP = gen_ip()
	#xbmc.log('IP ##################################################################'+str(IP),2)





#	sucuriFirewall = SucuriFirewall()
	#headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
	#			'X-Forwarded-For':IP}
	#cookies = sucuriFirewall.bypass('https://ustvgo.tv/')
	
#	cookies_check = sucuriFirewall.bypass('https://192.124.249.10')
#	cookies={cookies_check.split("=")[0]:cookies_check.split("=")[1].replace(";path","")}
#	html = requests.get(url, headers=headers, cookies=cookies)
#	data = html.content
#	xbmc.log('COOKIES CHECK ##################################################################'+str(data),2)

	#Regex = re.compile('<div id="main-content"(.+?)<aside class="mh-widget-col-1 mh-sidebar"',re.DOTALL).findall(data)
	#Regex2 = re.compile('<a class="mh-thumb-icon mh-thumb-icon-small-mobile".+?<img width=".+?height=".+?<noscript><img width=.+?src="(.+?)".+?</noscript>.+?<header class="mh-posts-list-header">.+?<a href="(.+?)" title=.+?>(.+?)</a></h3></header>',re.DOTALL).findall(str(Regex))

	#for icon,link,title in Regex2:
	#	title = title.replace("&#038;", "&")
	#	add_dir('','bws_get_playlinks',link,'[B][COLOR yellow]'+title+'[/COLOR][/B]',icon,icon,'[B][COLOR yellow]WATCH '+title+' LIVE STREAM[/COLOR][/B]')



#'GET LINKS CODE'
@route(mode='TM_links', args=["url"])
def TM_links(url):
	#xbmc.log('links##################################################################'+str(url),2)
	
	thisRegex2 = r'<url>(.+?)</url>'
	Regex_me = re.compile(thisRegex2,re.DOTALL).findall(url)
	#xbmc.log('Regex_me##################################################################'+str(Regex_me),2)
	
	countme = 1
	for url in Regex_me:
		#xbmc.log('1st##################################################################'+str(url),2)

		if 'no-url' in url:
			continue
			#xbmc.log('Regex_melinks##################################################################'+str(url),2)
		
		elif '|IPTV' in url:
			name = 'Link ' + str(countme)
		else:
			#xbmc.log('2links##################################################################'+str(url),2)
			try:
				name = url.split('//')[1].replace('www.','')
				name = name.split('/')[0].split('.')[0].title()
			except:pass	

		if 'Verystream' in name:
			name = name+' [COLOR red][B](NEED TO PLAY AGAIN IF IT DOESNT PLAY AT ONCE)[/COLOR]'

		if 'Onlystream' in name:
			name = name+' [COLOR red][B](NEED TO PLAY AGAIN IF IT DOESNT PLAY AT ONCE)[/COLOR]'

		#xbmc.log('Fst##################################################################'+str(url),2)
		#xbmc.log('Fst##################################################################'+str(name),2)

		
		add_dir('','Resolver',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,bg,desc)
		countme = countme + 1
		#add_dir('','Resolver',url,'[B][COLOR white]'+name+'[/COLOR][/B]','','','')

@route(mode='get_asian_movies_link', args=["url"])
def get_asian_links(url):
	preurl = 'https://dramacool9.com'
	url = preurl+url
	#xbmc.log('GETLINKS##################################################################'+str(url),2)

	scrape = kmovies.scrape_links(url)
	#xbmc.log('SCRAPE KMOVIES##################################################################'+str(scrape),2)
	
	thisRegex2 = r'<urlname>(.+?)</urlname><url>(.+?)</url>'
	Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(scrape))
	counter = 0
	
	for name,url in Regex_me:
		xbmc.log('URL##################################################################'+str(url),2)
		add_dir('','ResolverDramacool',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,thumb)
		# if 'embed.dramacool' in url:
		# 	add_dir('','ResolverDramacool',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,thumb)
		# elif 'kshows.to' in url:
		# 	add_dir('','ResolverKshows',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,thumb)
		# else:
		# 	add_dir('','Resolver',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,thumb)

		#try:
		#	name2 = url.split('//')[1].replace('www.','')
		#	name2 = name2.split('/')[0].split('.')[0].title()
		#except:pass'
		# try:
		
		# 	if resolveurl.HostedMediaFile(url).valid_url():
		# 		counter = counter + 1
		# 		if 'Verystream' in name2:
		# 			notice = ' [COLOR red][B](NEED TO PLAY AGAIN IF IT DOESNT PLAY AT FIRST)[/COLOR]'
		# 			name2 = name + notice
		# 			add_dir('','Resolver',url,'[B][COLOR white]'+name2+'[/COLOR][/B]',thumb,thumb)
		# 	else:
		# 		add_dir('','Resolver',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,thumb)
		# 		#xbmc.log('SCRAPE##################################################################'+str(a),2)
		# 		#xbmc.log('SCRAPE##################################################################'+str(links),2)
		# except:
		# 	pass
		# 	#add_dir('','Resolver',url,'[B][COLOR white]sorry[/COLOR][/B]',thumb,thumb,name2)
		# if counter > 0:
		# 	pass
		# else:
		# 	add_dir('','','','[B][COLOR red]SORRY NO PLAYABLE LINK FOUND, PLS TRY OTHER SOURCES[/COLOR][/B]',thumb,thumb,name2)
	
@route(mode='get_series9_links', args=["url"])                                      # This must match one of the modes called above 
def get_series9_links(url):
	#https://www2.seriesonline8.co/movie/filter/series-featured/all/all/all/all/latest/
	#url2 ='https://www2.seriesonline8.co'+ url + '/watching.html?ep=0'
	url2 ='https://www2.series9.io'+ url + '/watching.html?ep=0'
	#xbmc.log('LINK URL############################################'+str(url),2)

	#pd = xbmcgui.DialogProgress()
	#pd.create('Please Wait ...Dont Cancel')


	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url2, headers=headers)

	html = Readit.content
	#xbmc.log('html############################################'+str(Readit),2)
		   
	ep = re.compile('<div class="les-content">.+?player-data=.+?episode-data="(.+?)"',re.DOTALL).findall(html)[0]
	#xbmc.log('EP##################################################################################'+str(ep),2)
	match = re.findall(r'player-data="(.+?)" episode-data="'+ep+'"', html)
	
	#block1 = re.compile('<strong>Server</strong>(.+?)<div class="mvi-content">',re.DOTALL).findall(html)
	#<a title="The 100 - Season 6 Episode 5 - The Gospel of Josephine" player-data="https://www.xstreamcdn.com/v/w3ygxbn62pjjpk-#caption=https://sub.movie-series.net/the-100-season-6-episode-5-the-gospel-of-josephine/the-100-season-6-episode-5-the-gospel-of-josephine.vtt" episode-data="5" id-data=
	#tring = r'<a title=".+?player-data="(.+?)" episode-data="5"'
	#xbmc.log('MATCHESSSSSSSME REGEX##################################################################################'+str(string),2) 
	#thisRegex2 = r'player-data="(.+?)" episode-data="5".+?class="btn-eps first-ep'
	#match = re.compile(thisRegex2,re.DOTALL).findall(str(html))
	#match = re.compile('<a title=".+?player-data="(.+?)" episode-data="'+ep+'"',re.DOTALL).findall(str(block1))
	#xbmc.log('MATCH BLOCK! REGEX##################################################################################'+str(match),2) 
	

	#m = len(match)
	#per = 100/m
	#c=0
	
	for link in match:
		#xbmc.log('LINK############################################'+str(link),2)
	# 	pd.update(int(c*per),line1='[B][COLOR red]Required Pairing with olpair.com/pair & vev.io/pair[/COLOR][/B]',line2='[B][COLOR yellow]Adding & Checking Url {}[/COLOR][/B]'.format(link))
		if '?c1_file' in link:
			link = link.split('?c1_file')[0]
		elif '#caption=https' in link:
			link = link.split('#caption=https')[0]
		elif 'http' not in link:
			link = 'http:' + link
		
		try:
			name = link.split('//')[1].replace('www.','')
			name = name.split('/')[0].split('.')[0].title()
		except:pass
		
		#try:
		#	link2 = link.split('?c1_file')[0]
	# 		#name = name.split('/')[0].split('.')[0].title()
		#except:pass
		#try:
		#	link2 = link.split('#caption=https')[0]
	# 		#name = name.split('/')[0].split('.')[0].title()
		#except:pass
	# 	a = resolveme.Resolve_list(url)
	# 	xbmc.log('LINK2############################################'+str(a),2)
		#if a:
		if  resolveurl.HostedMediaFile(link).valid_url():	 		
		#	add_dir('','Direct_Link',a,'[B][COLOR white]'+name+'[/COLOR][/B]','','')
	# 	#if 'vshare' in link:
			add_dir('','Resolver',link,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,Fanart)

	# 	#elif 'openload' in link:
	# 	# 	add_dir('','Resolver',link,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,Fanart)

	# 	# 		#elif 'vidto' in link:
	# 	# 		#	add_dir('f','get_links',link,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,'',info)
				

	# 	#elif 'vev' in link:
	# 	 #	add_dir('','Resolver',link,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,Fanart)
				
	# 	#else:                  
	# 	#	try:
	# 			#if 'vidcloud' in link:
	# 			#	Readit2 = requests.get(url2, headers=headers)
	# 			#html2 = Readit2.content
	# 			#block1 = re.compile('<strong>Server</strong>(.+?)<div class="mvi-content">',re.DOTALL).findall(html)
	# 	#		if  resolveurl.HostedMediaFile(link).valid_url():

	# #			a = resolveme.Resolve_list(link)
	# #			if a:
	# 	#			add_dir('','Resolver',link,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,Fanart)
	# # 			bilang = bilang + 1
	# # 					#link_list.append(link)
						
	# # 		#		else:
	# # 					#dialog.ok('PLAYBACK FAILED','Sorry, playback failed :(')
	# # 		#			continue
	# 	#	except:
	# 	#		continue
		
	# 	c += 1
	# pd.close()

@route(mode='mkvhub_getlinks2', args=["url"])
def mkvhub_getlinks2(url):
	#xbmc.log('getlinksurl##################################################################'+str(url),2)
	if 'mkvhub' in url:

		scrape = mkv.scrape_links(url)	
		thisRegex2 = r'<url>(.+?)</url>'
		Regex_me = re.compile(thisRegex2,re.DOTALL).findall(str(scrape))
		counter = 0
		#xbmc.log('Count SCRAPE##################################################################'+str(counter),2)
		for url in Regex_me:
			try:
				name2 = url.split('//')[1].replace('www.','')
				name2 = name2.split('/')[0].split('.')[0].title()
			except:pass
			try:				
				if resolveurl.HostedMediaFile(url).valid_url():
					counter = counter + 1
					if 'Verystream' in name2:
						notice = ' [COLOR red][B](NEED TO PLAY AGAIN IF IT DOESNT PLAY AT FIRST)[/COLOR]'
						name2 = name2 + notice
					add_dir('','Resolver',url,'[B][COLOR white]'+name2+'[/COLOR][/B]',thumb,thumb,name2)
				#xbmc.log('SCRAPE##################################################################'+str(a),2)
				#xbmc.log('SCRAPE##################################################################'+str(links),2)
			except:
				pass
			#add_dir('','Resolver',url,'[B][COLOR white]sorry[/COLOR][/B]',thumb,thumb,name2)
		if counter > 0:
			pass
		else:
			add_dir('','','','[B][COLOR red]SORRY NO PLAYABLE LINK FOUND, PLS TRY OTHER SOURCES[/COLOR][/B]',thumb,thumb,name2)
			#xbmc.log('SCRAPE##################################################################'+str(scrape),2)
	# xbmc.log('SCRAPE##################################################################'+str(counter),2)





#END CODE HERE

#bathala_web_scrape
#@bws_get_playlinks
# @route(mode='bws_get_playlinks', args=["url"])
# def bws_get_playlinks(url):
# 	sucuriFirewall = SucuriFirewall()
# 	headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
# 	#cookies = sucuriFirewall.bypass('https://ustvgo.tv/')
# 	cookies_check = sucuriFirewall.bypass(url)
# 	cookies={cookies_check.split("=")[0]:cookies_check.split("=")[1].replace(";path","")}
# 	html = requests.get(url, headers=headers, cookies=cookies)
# 	data = html.content

# 	link_frame = re.compile("<iframe src='(.+?)'",re.DOTALL).findall(data)
	
# 	for links in link_frame:
# 		link_holder = "https://ustvgo.tv"+links
# 		Read_cookies_link_holder = sucuriFirewall.bypass(link_holder) 
	
# 		cookies_link_holder = {Read_cookies_link_holder.split("=")[0]:cookies_check.split("=")[1].replace(";path","")}

# 		html_link_holder = requests.get(url=link_holder, headers=headers, cookies=cookies_link_holder)
# 		data_link_holder = html_link_holder.content
# 		Regex = re.compile("file: '(.+?)'",re.DOTALL).findall(data_link_holder)
# 		play_link = Regex[0]+"|User-Agent=Mozilla/5.0 (Linux; U; Android 7.1.1; en-US; SM-T560NU Build/NMF26X"
# 		xbmc.log('play_link ##################################################################'+str(play_link),2)

# 	lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
# 	lis.setInfo( type="Video", infoLabels={"Title": title})
# 	lis.setProperty("IsPlayable","true")
# 	lis.setPath(play_link)
# 	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)

		






def Play(url,title,thumb):
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	lis	= xbmcgui.ListItem(title,iconImage=iconimage,thumbnailImage=iconimage)
	lis.setInfo(type='Video', infoLabels ={'Title':title,"Plot":description})
	lis.setPath(url)
	player.play(url, lis)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	for i in range(0, 120):
		if player.isPlayingVideo(): break
		xbmc.sleep(1000)
	while player.isPlaying():
		xbmc.sleep(2000)
	xbmc.sleep(4000)





params = Get_Params()
mode = None

try: mode = params['mode']
except: pass
try: url = params['url']
except: pass
try: title = params['title']
except: pass
try: thumb = params['iconimage']
except: pass
try: bg = params['fanart']
except: pass
try: desc = params['description']
except: pass


#if mode == None or len(sys.argv[2])<2: Menu()
@route(mode='Direct_Link', args=["url"])
def Direct_Link(url):
	try:
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	except:
		pass

@route(mode='ResolverDramacool', args=["url"])
def ResolverDramacool(url):
	try:
		try:
			useragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://embed.dramacool.movie/'
			url = url + useragent 			
			#stream_url = resolveurl.resolve(url)
			lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
			lis.setInfo( type="Video", infoLabels={"Title": title})
			lis.setProperty("IsPlayable","true")
			lis.setPath(url)
			#xbmcgui.Dialog().notification(addon_name + ' is provided by:','Team Kepweng',Icons2 + 'icon2.png',10000,False)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
		except:
			stream_url = resolveurl.resolve(url)
			lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
			lis.setInfo( type="Video", infoLabels={"Title": title})
			lis.setProperty("IsPlayable","true")
			lis.setPath(stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
		
	except:
		pass
		# 	#xbmc.log('RESOLVERpass######################################################### '+str(url),2)
		xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")
	quit()
	return




@route(mode='ResolverKshows', args=["url"])
def ResolverKshows(url):
	try:
		#stream_url = resolveurl.resolve(url)
		

		#elif 'kshows.to' in url:
		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
		Readit = requests.get(url,headers=headers)
		html = Readit.content
		block = re.compile('<div id="myVideo">(.+?)</script>',re.DOTALL).findall(html)[0]
		matches = re.findall('(?s)sources\:\[\{file\: \'(.+?)\',label\:',block)[0]
		#xbmc.log('EMBED LINK######################################################### '+str(block),2)
		if '.m3u8' in matches:
			newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://k-vid.net/'
			stream_url = matches + newuseragent
			stream_url = str(stream_url)
		else:
			stream_url = resolveurl.resolve(matches)
		
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
		
	except:
		pass		
	# 	#xbmc.log('RESOLVERpass######################################################### '+str(url),2)
		xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")
	quit()
	return

@route(mode='Resolver', args=["url"])
def Resolver(url):
	try:
		stream_url = resolveurl.resolve(url)
		xbmc.log('SSTREAM_url######################################################### '+str(url),2)
		xbmc.log('SSTREAM_url######################################################### '+str(stream_url),2)
		lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
		lis.setInfo( type="Video", infoLabels={"Title": title})
		lis.setProperty("IsPlayable","true")
		lis.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
		#xbmc.log('SUCCESS RESOLVER######################################################### '+str(url),2)

	except:
		pass
		Old_Resolver(url)		
	
	#	xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]SORRY[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")
	#quit()
	#return

@route(mode='Old _Resolver', args=["url"])
def Old_Resolver(url):
	#xbmc.log('FIRST RESOLVER TRY######################################################### '+str(url),2)
	try:
		if '.m3u8' in url:
	 		stream_url = url

	 	elif '.mp4' in url:
	 		stream_url = url
		
	 	elif '|IPTV' in url:			
	 		newuseragent = '|Dalvik/2.1.0 (Linux; U; Android 5.1; AFTM Build/LMY47O)'
	 		new_url = url.split('|IPTV')[0]
	 		#xbmc.log('2nd TRY######################################################### '+str(new_url),2)
	 		stream_url = new_url + newuseragent	

		elif 'streamhoe.online' in url:	 			 		
	 		url = url.replace('https://streamhoe.online/v/','')
	 		post_url = 'https://streamhoe.online/api/source/'+ url
	 		#xbmc.log('STREAMHOE URL ID######################################################### '+str(url),2)
	 		
	 		#xbmc.log('STREAMHOE URL######################################################### '+str(post_url),2)

			headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
						'authority': 'streamhoe.online',
						'origin': 'https://streamhoe.online',
						'referer': url} # need to redo this
			myobj = {'r': '','d': 'streamhoe.online'}

			temp = requests.post(post_url, data = myobj, headers=headers)
			html = temp.text
			regexme = r'\{"file":"(.+?)","label":".+?","type":"mp4"},'
			match = re.compile(regexme,re.DOTALL).findall(html)[0]
			strurl = match.replace('\/\/','//').replace('\/','/')
			xbmc.log('STREAMHOE HTMLL######################################################### '+str(match),2)
			newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer='+url
			stream_url = strurl + newuseragent
			#link = match[0]
			#xbmc.log('STREAMHOE MATCH######################################################### '+str(html),2)
			xbmc.log('STREAMHOE MATCH######################################################### '+str(stream_url),2)

	 		# quality_name = []
	 		# stream_url = []
	 		# host = ''

	 		# for strurl,quality in match:
	 		# 	strurl = strurl.replace('https:\/\/fvs.io\/','https://fvs.io/')
	 		# 	#xbmc.log('QUALITY block1######################################################### '+str(quality_name),2)
				# #xbmc.log('QUALITY block1######################################################### '+str(strurl),2)
				
	 		# 	host = '[B][COLOR yellow]%s[/COLOR][/B]' %quality
	 		#  	quality_name.append(host)
	 		#  	stream_url.append(strurl)

				

	 		# try:
	 		# 	if len(match) >0:
	 		# 		dialog = xbmcgui.Dialog()
	 		#  	ret = dialog.select('Please Select Quality',quality_name)
	 		 	
	 		#  	if ret < 0:
	 		#  		return
	 		#  	elif ret > -1:
	 		#  		newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'
	 		#  		holder = stream_url[ret]
	 		#  		stream_url = holder + newuseragent

	 		# except:pass



	# 	elif 'mstream' in url:
	# ## 		xbmc.log('MSTREAM URL ######################################################### '+str(url),2)
	# 		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	# 		temp = requests.get(url, headers=headers)
	# 		html = temp.text
	# # 		xbmc.log('MSTREAm HTML######################################################### '+str(html),2)
	# 		regexme = r'<meta name="og:image" content="(.+?)/splash.jpg">'
	# 		match = re.compile(regexme,re.DOTALL).findall(html)[0]
	# 		newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer='+url
	# 		match = match + '.mp4'
	# 		stream_url = match + newuseragent

		elif 'viduplayer.com/embed' in url:
			headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
			temp = requests.get(url, headers=headers)
			html = temp.text
			unpacked = helpers.get_packed_data(html)
	# 		xbmc.log('play link######################################################### '+str(unpacked),2)
			
			if unpacked:
			 	match2 = re.compile('\,\{file:"(.+?)",label:"(.+?)"',re.DOTALL).findall(str(unpacked))
	# 		 	xbmc.log('play link######################################################### '+str(match2),2)
			
			quality_name = []
			stream_url = []
			host = ''

			for strurl,quality in match2:
				
				host = '[B][COLOR yellow]%s[/COLOR][/B]' %quality
			 	quality_name.append(host)
			 	stream_url.append(strurl)

	# 		# # # 	#xbmc.log('QUALITY block1######################################################### '+str(quality_name),2)
	# 		# # # 	#xbmc.log('QUALITY block1######################################################### '+str(stream_url),2)

			try:
				if len(match2) >0:
					dialog = xbmcgui.Dialog()
			 	ret = dialog.select('Please Select Quality',quality_name)
			 	if ret < 0:
			 		return
			 	elif ret > -1:
			 		newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'
			 		holder = stream_url[ret]
			 		stream_url = holder + newuseragent

			except:pass

	#  	elif 'vidcloud9'  or 'vidnode' in url:
	# 		headers = {'Referer': url,
	# 					'X-Requested-With': 'XMLHttpRequest',
	# 					'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}

	# 		url = 'https://vidcloud9.com/ajax.php?id=NTU0MTI='

	# 		match2 = re.compile('\,\{file:"(.+?)",label:"(.+?)"',re.DOTALL).findall(str(unpacked))

			


	# 		temp = requests.get(url, headers=headers)
	# 		html = temp.text
	# 		xbmc.log('VIDNODE play link######################################################### '+str(html),2)
			
	# 		regexme = r"\{file\: '(.+?)',label\:.+?'type' \: 'mp4'}"
	# 		match = re.compile(regexme,re.DOTALL).findall(html)[0]
	# 		newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Origin=https://vidcloud9.com&Referer=https://vidcloud9.com/'
	#  		#{file: '',label: 'auto P','type' : 'mp4'}
	# # 		#xbmc.log('VIDNODE play link######################################################### '+str(match),2)
	# 		stream_url = match + newuseragent		

		
		#elif 'mixdrop' in url:
		#	dialog.ok('SORRY WRONG PASSWORD', +str(url))

		#	xbmc.log('MIXDRoP URL ######################################################### '+str(url),2)
			
			#headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
			#temp = requests.get(url, headers=headers)
			#html = temp.text
			#unpacked = helpers.get_packed_data(html)
			#headers = {'Origin':'https://mixdrop.co','Referer': url,'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
			#newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=url&Origin=https://mixdrop.co'
			#regexme = r'(?:vsr|wurl|surl)[^=]*=\s*"([^"]+)'
			#match = re.compile(regexme,re.DOTALL).findall(unpacked)[0]
			#link = 'https:' + match
			#play_link = link + newuseragent
			#xbmc.log('unpacked TRY######################################################### '+str(unpacked),2)
			#xbmc.log('play link######################################################### '+str(match),2)
			#xbmc.log('play link######################################################### '+str(play_link),2)
	 		#stream_url = play_link
	


	# try:
	
		



		


	# 	#https://streamhoe.online/v/qkn82iekgyknxn1
	# 	elif 'streamhoe.online' in url:
	# 		#https://www.fembed.com/v/5dr6xfdq61ew0dn
	# 		#https://feurl.com/v/76w28tgdl5236my
	# 		url = url.replace('streamhoe.online','feurl.com')
	# 		#xbmc.log('play link######################################################### '+str(url),2)
	# 		stream_url = resolveurl.resolve(url2)

			

	# 	elif 'embed.mystream.to' in url:
	# 		#https://embed.mystream.to/0cpo0qsqwh87
	# 		#https://mstream.xyz/0cpo0qsqwh87
			
	# 		url = url.replace('embed.mystream.to','mstream.xyz')
	# 		xbmc.log('play link######################################################### '+str(url),2)
	# 		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	# 		temp = requests.get(url, headers=headers)
	# 		html = temp.text
			
	# 		regexme = r'<meta name="og:image" content="(.+?)/splash.jpg">'
	# 		match = re.compile(regexme,re.DOTALL).findall(html)[0]
	# 		newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'
	# 		match = match + '.mp4'
	# 		stream_url = match + newuseragent

	# 	elif 'gounlimited' in url:
	# 		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	# 		temp = requests.get(url, headers=headers)
	# 		html = temp.text
	# 		unpacked = helpers.get_packed_data(html)
			
	# 		regexme = r'var player\=new Clappr\.Player\(\{sources\:\["(.+?)"\]'
	# 		match = re.compile(regexme,re.DOTALL).findall(unpacked)[0]
	# 		newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'
	# 		stream_url = match
	# 		#xbmc.log('play link######################################################### '+str(match),2)






	# 	elif 'vstream.me' in url:
	# 		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	# 		temp = requests.get(url, headers=headers)
	# 		html = temp.text
	# 		regexme = r'<script type="text/javascript">var sources = \[(.+?)\]'
	# 		match = re.compile(regexme,re.DOTALL).findall(html)
	# 		match2 = re.compile('"file":"(.+?)","label":"(.+?)"',re.DOTALL).findall(str(match))
	# 		#xbmc.log('play link######################################################### '+str(match2),2)

	# 		quality_name = []
	# 		stream_url = []
	# 		host = ''

	# 		for strurl,quality in match2:
	# 		#xbmc.log('play link######################################################### '+str(quality),2)
	# 		#xbmc.log('play link######################################################### '+str(strurl),2)

	# 		# 	if '144' in quality:
	# 		# 		if '480' in str(mb):
	# 		# 			continue
	# 		# 		else:
	# 		# 			quality = 'Very Low'
	# 		# 	if '240' in quality:
	# 		# 		if '480' in str(mb):
	# 		# 			continue
	# 		# 		else:
	# 		# 			quality = 'Very Low'
	# 		# 	if '380' in quality:
	# 		# 		quality = 'Low SD'
	# 		# 	if '480' in quality:
	# 		# 		quality = 'SD'
	# 			#if '720' in quality:
	# 			#	quality = '720p HD'
	# 			#else:
	# 			#	quality = 'SD Quality'
				
	# 			host = '[B][COLOR yellow]%s[/COLOR][/B]' %quality
	# 			quality_name.append(host)
	# 			stream_url.append(strurl)

	# 		# # 	#xbmc.log('QUALITY block1######################################################### '+str(quality_name),2)
	# 		# # 	#xbmc.log('QUALITY block1######################################################### '+str(stream_url),2)

	# 		try:
	# 				#if len(match2) >0:
	# 			dialog = xbmcgui.Dialog()
	# 			ret = dialog.select('Please Select Quality',quality_name)
	# 			if ret < 0:
	# 				return
	# 			elif ret > -1:
	# 				newuseragent = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'
	# 				holder = stream_url[ret]
	# 				stream_url = holder + newuseragent

	# 			#lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
	# 			#lis.setInfo( type="Video", infoLabels={"Title": title})
	# 			#lis.setProperty("IsPlayable","true")
	# 			#lis.setPath(url)
	# 			#xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	# 		except:pass

		
	
		

		
	# 	elif 'iwantprada' in url:
	# 		stream_url = url
	# 		xbmc.log('2nd TRY######################################################### '+str(stream_url),2)



	 	else:
			#xbmc.log('2nd TRY######################################################### '+str(url),2)

	 		stream_url = resolveurl.resolve(url)	
		
	 	lis = xbmcgui.ListItem(title,iconImage=thumb, thumbnailImage=thumb)
	 	lis.setInfo( type="Video", infoLabels={"Title": title})
	 	lis.setProperty("IsPlayable","true")
	 	lis.setPath(stream_url)
	 	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
		
	except:

		pass
	 	#xbmc.log('RESOLVERpass######################################################### '+str(url),2)
		xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]SORRY[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")
	quit()
	return



class SucuriFirewall():
	def __init__(self):
		self.header = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
						'X-Forwarded-For':'3.179.102.135'}
		
		self.cookie = None


	def bypass(self, page):
		try:
			self.page = page
			result = requests.get(self.page, headers=self.header).content
			s = re.compile("S\s*=\s*'([^']+)").findall(result)[0]
			s = base64.b64decode(s)
			s = s.replace(' ', '')
			s = re.sub('String\.fromCharCode\(([^)]+)\)', r'chr(\1)', s)
			s = re.sub('\.slice\((\d+),(\d+)\)', r'[\1:\2]', s)
			s = re.sub('\.charAt\(([^)]+)\)', r'[\1]', s)
			s = re.sub('\.substr\((\d+),(\d+)\)', r'[\1:\1+\2]', s)
			s = re.sub(';location.reload\(\);', '', s)
			s = re.sub(r'\n', '', s)
			s = re.sub(r'document\.cookie', 'cookie', s)
			cookie = '';
			s_exec = compile(s, 'sumstring', 'exec')			
			exec (s_exec)
			#exec (s)
			self.cookie = re.compile('([^=]+)=(.*)').findall(cookie)[0]
			self.cookie = '%s=%s' % (self.cookie[0], self.cookie[1])
			return self.cookie
		except:
			return self.cookie
	



router.Run('Login')
xbmcplugin.endOfDirectory(addon_handle)

